#include <windows.h>
#include <assert.h>
//Statics

/*double DENSITY  =       5;//���ʖ��x
double GRAVITY_CONST=	20;//�d�͒萔
double UKAWA_CONST =1;//����|�e���V�����萔�i�ʁj
double POTENTIAL_CONST= 0;//�O���|�e���V�����̋���
double POTENTIAL_RANGE =0;//�O���|�e���V�������B�̈�
double MEAN_RADIUS =2;//���ϔ��a
double RADIUS_sigma =10;//���a���U
double MEAN_VELOCITY =0;//���ϑ��x
double VELOCITY_sigma =50;//���ϕ��U*/
#define SIZEX 1000//�ړ���
#define SIZEY 700//�ړ���

class ParticleDebug{
public:
	double data[6];
	const double& operator[](int i) const{
		assert(0<=i&&i<6);
		return data[i];
	}
	double& operator[](int i){
		assert(0<=i&&i<6);
		return data[i];
	}
};
/*/
typedef ParticleDebug ParticleData;
/*/
typedef double ParticleData[6];
//*/

class ParticleArray{
private:
	ParticleData* data;
	int n;
	void free(){
		if(this->data==NULL)return;
		delete[] this->data;
		this->data=NULL;
	}
public:
	ParticleArray(int n):n(n){
		this->data=new ParticleData[n];
	}
	~ParticleArray(){
		this->free();
	}
	ParticleArray& operator=(const ParticleArray& copyee){
		this->realloc(copyee.n);
		memcpy(this->data,copyee.data,sizeof(double)*n);
		return *this;
	}
	void realloc(int n){
		this->free();
		this->n=n;
		this->data=new ParticleData[n];
	}
	ParticleData& operator[](int i){
#ifndef NDEBUG
		if(!(0<=i&&i<n))
			printf("�~");
#endif
		assert(0<=i&&i<n);
		return data[i];
	}
	const ParticleData& operator[](int i) const{
#ifndef NDEBUG
		if(!(0<=i&&i<n))
			printf("�~");
#endif
		assert(0<=i&&i<n);
		return data[i];
	}
};

//Functions
double Min(double a,double b);
double Max(double a,double b);
double distance1(double x1,double y1, double x2,double y2,double sx,double sy);
double distance2(double x1,double y1, double x2,double y2);
double gravity(double r,double m1,double m2);
void timedev(ParticleArray&  particleA,ParticleArray&  particleB,double h,double sx,double sy,double &T,int &kara);
void init(ParticleArray& particleA,double T,double sx,double sy);
void Draw(const ParticleArray&  particleA,HDC hdc,HDC hBuffer,HWND hWnd);
//double potential(double x,double y,double sx,double sy,double m);
double Vdev(ParticleData& particle1,ParticleData& particle2,double sign,double Force,double s,int i);
//void timedev_Runge1(double (*particlek)[4],ParticleArray& particleA,double h,double sx,double sy,double T);
//void timedev_Runge2(double (*particlek)[4],double (*particlek1)[4],ParticleArray& particleA,double h,double sx,double sy,double T);
//void timedev_Runge3(double (*particlek)[4],double (*particlek2)[4],ParticleArray& particleA,double h,double sx,double sy,double T);
//void timedev_Runge4(double (*particlek)[4],double (*particlek3)[4],ParticleArray& particleA,double h,double sx,double sy,double T);
