
#include <iostream>
using namespace std;

//����header file
//#include <MyDirectInput.h>
#include <tchar.h>

//const int	PARTICLE_NUM=5000;//���q��
int	PARTICLE_NUM=500;//���q��
double DENSITY  =       5.0;//���ʖ��x
double GRAVITY_CONST=	20.0;//�d�͒萔
double UKAWA_CONST =1.0;//����|�e���V�����萔�i�ʁj
double POTENTIAL_CONST= 0.0;//�O���|�e���V�����̋���
double POTENTIAL_RANGE =0.0;//�O���|�e���V�������B�̈�
double MEAN_RADIUS =2.0;//���ϔ��a
double RADIUS_sigma =10.0;//���a���U
double MEAN_VELOCITY =0.0;//���ϑ��x
double VELOCITY_sigma =50.0;//���ϕ��U
double biglight=1.0;//�g�嗦
int  bund=1;//���̗̂L��
int kara=PARTICLE_NUM-1;
#include "mayfes2009-cal-west.h"
#include "MyAPIInit.h"
#include "resource.h"
#include <cmath>
#define ID_TIMER 242424

const TCHAR gName[256] = _T("�́����̑��z�n�n���L");
//TCHAR gMenu[256] = _T("IDD_MENU");
//ParticleData* particleA = (ParticleData*)new double[PARTICLE_NUM*6];

//ParticleData* particleA=new ParticleData[PARTICLE_NUM];
ParticleArray particleA(PARTICLE_NUM);

//ParticleData *particleB = (ParticleData *)new double[PARTICLE_NUM*6];
//ParticleData *particleB=new ParticleData [PARTICLE_NUM];
ParticleArray particleB(PARTICLE_NUM);
//double (*particlek1)[4] = (double (*)[4])new double[PARTICLE_NUM*4];
//double (*particlek2)[4] = (double (*)[4])new double[PARTICLE_NUM*4];
//double (*particlek3)[4] = (double (*)[4])new double[PARTICLE_NUM*4];
//double (*particlek4)[4] = (double (*)[4])new double[PARTICLE_NUM*4];

/*ParticleArray& particleA;
double particlek1[PARTICLE_NUM][4];
double (*particlek2)[4];
double (*particlek3)[4];
double (*particlek4)[4];*/
int n=100;//��b������̕�����
double h=1/(double)n;//���ݕ�
double T=0;//�o�ߎ���
double sx=SIZEX;//�傫���i���j
double sy=SIZEY;//�傫���i���j


LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM); 

LRESULT CALLBACK WndProc(HWND hWnd,  UINT mes, WPARAM wp, LPARAM lp){
	HDC hdc;
	PAINTSTRUCT ps;
	
	static HDC hBuffer;
	static HBITMAP hBmp;

#pragma warning(disable:4312)
	HINSTANCE hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
#pragma warning(default:4312)

	switch(mes){
		case WM_CREATE:
			hdc = GetDC(hWnd);
			hBmp = CreateCompatibleBitmap(hdc, 1050, 700);
			hBuffer = CreateCompatibleDC(hdc);
			SelectObject(hBuffer, hBmp);
			ReleaseDC(hWnd, hdc);
			return 0;
		case WM_DESTROY:
			DeleteDC(hBuffer);
			DeleteObject(hBmp);
			PostQuitMessage(0);
			return 0;
		case WM_TIMER:
			//timedev_Runge1(particlek1,particleA,h,sx,sy,T);
			//timedev_Runge2(particlek2,particlek1,particleA,h,sx,sy,T);
			//timedev_Runge3(particlek3,particlek2,particleA,h,sx,sy,T);
			//timedev_Runge4(particlek4,particlek3,particleA,h,sx,sy,T);
			timedev(particleA,particleB,h,sx,sy,T,kara);
			InvalidateRect(hWnd,NULL,FALSE);
			return 0;

		case WM_COMMAND:
			switch(LOWORD(wp)){
				case ID_STOP:
					KillTimer(hWnd, ID_TIMER);
					return 0;
				case ID_START:
					SetTimer(hWnd, ID_TIMER, 50, NULL);
					return 0;
				case ID_SET:
					
					DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), hWnd,(DLGPROC)DlgProc);
					InvalidateRect(hWnd,NULL,FALSE);	
					return 0;
				case ID_INIT:
					init(particleA,sx,sy,T);
					return 0;
			}
			return 0;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			Draw(particleA,hdc,hBuffer,hWnd);			
			EndPaint(hWnd, &ps);
			return 0;
		default:
			return DefWindowProc(hWnd, mes, wp, lp);
	}
}

LRESULT CALLBACK DlgProc(HWND hDlg, UINT mes, WPARAM wp, LPARAM lp){
	char NUM[64];
	char G[64];
	char DEN[64];
	char RAD[64];
	char M_VELO[64];
	char SIG_VELO[64];
	char BIGLIGHT[64];
	char BUND[64];
	sprintf_s(NUM,64,"%d",PARTICLE_NUM);
	sprintf_s(G,64,"%lf",GRAVITY_CONST);
	sprintf_s(DEN,64,"%lf",DENSITY);
	sprintf_s(RAD,64,"%lf",MEAN_RADIUS);
	sprintf_s(M_VELO,64,"%lf",MEAN_VELOCITY);
	sprintf_s(SIG_VELO,64,"%lf",VELOCITY_sigma);
	sprintf_s(BIGLIGHT,64,"%lf",biglight);
	sprintf_s(BUND,64,"%d",bund);
	switch(mes){
		case WM_INITDIALOG:
			SetDlgItemText(hDlg, IDC_NUM, (LPTSTR)NUM);
			SetDlgItemText(hDlg, IDC_G, (LPTSTR)G);
			SetDlgItemText(hDlg, IDC_DEN, (LPTSTR)DEN);		
			SetDlgItemText(hDlg, IDC_RAD, (LPTSTR)RAD);
			SetDlgItemText(hDlg, IDC_M_VELO, (LPTSTR)M_VELO);
			SetDlgItemText(hDlg, IDC_SIG_VELO, (LPTSTR)SIG_VELO);
			SetDlgItemText(hDlg, IDC_BIGLIGHT, (LPTSTR)BIGLIGHT);
			SetDlgItemText(hDlg, IDC_bund, (LPTSTR)BUND);
			
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wp)){
			case IDOK:{
				GetDlgItemText(hDlg,IDC_NUM,(LPTSTR)NUM,sizeof(NUM));
				GetDlgItemText(hDlg,IDC_G,(LPTSTR)G,sizeof(G));
				GetDlgItemText(hDlg,IDC_DEN,(LPTSTR)DEN,sizeof(DEN));		
				GetDlgItemText(hDlg,IDC_RAD,(LPTSTR)RAD,sizeof(RAD));
				GetDlgItemText(hDlg,IDC_M_VELO,(LPTSTR)M_VELO,sizeof(M_VELO));
				GetDlgItemText(hDlg,IDC_SIG_VELO,(LPTSTR)SIG_VELO,sizeof(SIG_VELO));				
				GetDlgItemText(hDlg,IDC_BIGLIGHT,(LPTSTR)BIGLIGHT,sizeof(BIGLIGHT));				
				GetDlgItemText(hDlg,IDC_bund,(LPTSTR)BUND,sizeof(BUND));				
				PARTICLE_NUM=atoi(NUM);
				if(PARTICLE_NUM<0)
				{
					PARTICLE_NUM=abs(PARTICLE_NUM);
				}
				if(PARTICLE_NUM>50000)
				{
					PARTICLE_NUM=50000;
				}
				GRAVITY_CONST=atof(G);
				DENSITY=atof(DEN);
				if(DENSITY<0)
				{
					DENSITY=abs(DENSITY);
				}
				MEAN_RADIUS=atof(RAD);
				if((MEAN_RADIUS)*(MEAN_RADIUS)>1.5*15000.0/(double)PARTICLE_NUM)
				{
					MEAN_RADIUS=sqrt(1.5*15000.0/(double)PARTICLE_NUM);
				}
				if(MEAN_RADIUS<0)
				{
					MEAN_RADIUS=sqrt(1.5*15000.0/(double)PARTICLE_NUM);				
				}
				MEAN_VELOCITY=atof(M_VELO);
				VELOCITY_sigma=atof(SIG_VELO);
				if(VELOCITY_sigma<0)
				{
					VELOCITY_sigma=abs(VELOCITY_sigma);				
				}
				biglight=atof(BIGLIGHT);
				if((MEAN_RADIUS*biglight)*(MEAN_RADIUS*biglight)>6*15000.0/(double)PARTICLE_NUM)
				{
					biglight=sqrt(6*15000.0/(double)PARTICLE_NUM)/MEAN_RADIUS;
				}
				bund=atoi(BUND);
				if(bund!=1)
				{
					bund=0;
				}

				/*
				delete[] particleA;
				delete[] particleB;
				
				particleA = new ParticleData[PARTICLE_NUM];
				particleB = new ParticleData[PARTICLE_NUM];
				//*/

				particleA.realloc(PARTICLE_NUM);
				particleB.realloc(PARTICLE_NUM);
				
				init(particleA,sx,sy,T);
						
				EndDialog(hDlg, IDOK);
				break;
			}
			case IDCANCEL:
				EndDialog(hDlg, IDCANCEL);
				break;
			}
			return FALSE;
		default:
			return FALSE;
	}
	return TRUE;
}
int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR llpCmdLine, int nCmdShow){
	MSG msg;
	HWND hWnd;
	WNDCLASSEX wcex;

	//������
	init(particleA,sx,sy,T);
	
	//�A�v���P�[�V�����̏�����
	if(!MyAPIInit(&hWnd, hInstance, &wcex, gName, MAKEINTRESOURCE(IDD_MENU), WndProc)){
		return 0;
	}


	ShowWindow(hWnd, nCmdShow);

	SetTimer(hWnd,ID_TIMER,20,NULL);//�`�摬�x

	do{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)){
			DispatchMessage(&msg);
		}
	}while(msg.message != WM_QUIT);

	
KillTimer(hWnd,ID_TIMER);
	return 0;
}