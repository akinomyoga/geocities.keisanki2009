//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dialogbox.rc
//
#define IDD_DIALOG1                     101
#define IDD_MENU                        103
#define IDC_NUM                         1002
#define IDC_G                           1003
#define IDC_DEN                         1004
#define IDC_RAD                         1005
#define IDC_M_VELO                      1006
#define IDC_SIG_VELO                    1007
#define IDC_BIGLIGHT                    1010
#define IDC_bund                        1011
#define ID_SET                          40004
#define ID_STOP                         40005
#define ID_START                        40007
#define ID_INIT                         40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
