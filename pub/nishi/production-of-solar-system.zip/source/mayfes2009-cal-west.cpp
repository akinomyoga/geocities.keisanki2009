// mayfes2009-cal-west.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

//#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <cmath>
#include <cfloat>
#include <ctime>
#pragma comment(lib,"gsl.lib")
//#pragma comment(lib,"gslcblas.lib")
#include <iostream>


#include <gsl/gsl_randist.h>
#include <gsl/gsl_rng.h>

	using namespace std;
extern int	PARTICLE_NUM;
extern double DENSITY  ;//���ʖ��x
extern double GRAVITY_CONST;//�d�͒萔
extern double UKAWA_CONST ;//����|�e���V�����萔�i�ʁj
extern double POTENTIAL_CONST;//�O���|�e���V�����̋���
extern double POTENTIAL_RANGE;//�O���|�e���V�������B�̈�
extern double MEAN_RADIUS ;//���ϔ��a
extern double RADIUS_sigma;//���a���U
extern double MEAN_VELOCITY;//���ϑ��x
extern double VELOCITY_sigma;//���ϕ��U
extern double biglight;
extern int kara;
extern int  bund;
extern int yoin;
#include "mayfes2009-cal-west.h"

//ParticleArray& particleA;//���q�`
//ParticleArray& particleA;//���q�a

double Min(double a,double b)
{
	if(a>b)
	{
		return b;
	}
	else
	{
		return a;
	}
}


double Max(double a,double b)
{
	if(a>b)
	{
		return a;
	}
	else
	{
		return b;
	}
}


//�����֐�(�C����)
double distance1(double x1,double y1, double x2,double y2,double sx,double sy)//�����֐�
{	
	double w;
	w=Min((x1-x2)*(x1-x2),(sx-(Max(x1,x2)-Min(x1,x2)))*(sx-(Max(x1,x2)-Min(x1,x2))))+Min((y1-y2)*(y1-y2),(Min(y1,y2)+sy-Max(y1,y2))*(Min(y1,y2)+sy-Max(y1,y2)));
	return sqrt(w);
}

//�����֐�(�C���O)
double distance2(double x1,double y1, double x2,double y2)
{	
	double l;
	l=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
	return sqrt(l);
}
double gravity(double r,double m1,double m2)//�d�͊֐�
{
	return -GRAVITY_CONST*m1*m2/(r*r);
}


double Vdev(ParticleData& particle1,ParticleData& particle2,double sign,double Force,double s,int i)
{
 return sign*(Force*Min(abs(particle1[i-2]-particle2[i-2]),s-abs(particle1[i-2]-particle2[i-2])));

}

void Draw(const ParticleArray& particleA,HDC hdc,HDC hBuffer,HWND hWnd)
{
	HPEN hPen,hOldPen;
	HBRUSH hBrush,hOldBrush;
	
	RECT rt;
	GetClientRect(hWnd,&rt);
	FillRect(hBuffer,&rt,(HBRUSH)GetStockObject(WHITE_BRUSH));
	
	for(int i=0;i<kara+1;i++)
	{
			//int color=(int)(particleA[i][1]/MEAN_RADIUS);
			//	Ellipse(hBuffer, 0, 0, 10, 10);
			hPen=CreatePen(PS_SOLID,1,RGB(70*i,60*i,50*i));
			hBrush=CreateSolidBrush(RGB(70*i,60*i,50*i));
			hOldPen=(HPEN)SelectObject(hBuffer,hPen);
			hOldBrush=(HBRUSH)SelectObject(hBuffer,hBrush);
			Ellipse(hBuffer,
				int(particleA[i][2]-biglight*particleA[i][1]),
				int(particleA[i][3]-biglight*particleA[i][1]),
				int(particleA[i][2]+biglight*particleA[i][1]),
				int(particleA[i][3]+biglight*particleA[i][1])
				);
			SelectObject(hBuffer,hOldPen);
			SelectObject(hBuffer,hOldBrush);
			DeleteObject(hPen);
			DeleteObject(hBrush);
	}
	
	BitBlt(hdc,rt.left,rt.top,rt.right,rt.bottom,hBuffer,0,0,SRCCOPY);	
	return;
}
void init(ParticleArray& particleA,double sx,double sy,double T,int &yoin)
{
		yoin=0;
		T=0;//�o�ߎ���
		kara=PARTICLE_NUM-1;
        gsl_rng * r;
		gsl_rng_env_setup();
		r = gsl_rng_alloc(gsl_rng_default);
		gsl_rng_set(r,(unsigned)time(NULL));
		srand((unsigned int)time(NULL));

		//��������
		
		for(int i=0;i<PARTICLE_NUM;i++)
		{	
			particleA[i][1]=gsl_ran_poisson (r,MEAN_RADIUS);//���a
			particleA[i][0]=DENSITY*particleA[i][1]*particleA[i][1]*M_PI;//����
			particleA[i][2]=sx*rand()/RAND_MAX; //�����W
			particleA[i][3]=sy*rand()/RAND_MAX; //�����W
		
			double Velocity=MEAN_VELOCITY+gsl_ran_gaussian (r,VELOCITY_sigma);//����
		
			double sita = 4*M_PI*rand()/RAND_MAX;//���x����
			particleA[i][4]=Velocity*cos(sita); //���������x
			particleA[i][5]=Velocity*sin(sita);//���������x
		}
	
		gsl_rng_free(r);
return;
}

void timedev(ParticleArray& particleA,ParticleArray& particleB,double h,double sx,double sy,double &T,int &kara)//���Ԕ��W�֐�
{	
			
			//���q�a�ɒl���
			for(int k=0;k<kara+1;k++)
			{	
				for(int l=0;l<6;l++)
				{
					particleB[k][l]=particleA[k][l];
			
				}
			}
	
		//���q�`�̈ʒu�̎��Ԕ��W(�I�C���[�@)
		for(int k=0;k<kara+1;k++)
		{	
				//����
				particleA[k][2]+=particleB[k][4]*h;
						
				while(particleA[k][2]>sx)
					{
						particleA[k][2]=particleA[k][2]-sx;
					}
				while(particleA[k][2]<0.0)
					{
						particleA[k][2]=particleA[k][2]+sx;
					}
				//����
				particleA[k][3]+=particleB[k][5]*h;
						
				while(particleA[k][3]>sy)
					{
						particleA[k][3]=particleA[k][3]-sy;
					}
				while(particleA[k][3]<0.0)
					{
						particleA[k][3]=particleB[k][3]+sy;
					}	
			
		}
		if(bund==1)
		{
		for(int i=0;i<kara+1;i++)
		{
			for(int j=i+1;j<kara+1;j++)
				{
					if(particleA[i][0]*particleA[j][0]>0.0)
					{
						double length=distance1(particleB[i][2],particleB[i][3],particleB[j][2],particleB[j][3],sx,sy);//���qi�Ɨ��qj�̋���
						//double length2=distance2(particleB[i][2],particleB[i][3],particleB[j][2],particleB[j][3]);//���qi�Ɨ��q���̌������̋���
						double Force=gravity(length,particleB[i][0],particleB[j][0]);//���qi�Ɨ��qj�̑��ݍ�p��
						double signx,signy;//�͂̌���
						double ax,ay;
						double bx,by;
						if(particleB[i][2]>particleB[j][2])
						{
							ax=1.0;
						}
						else
						{
							ax=-1.0;
						}
						if(Min(abs(particleB[i][2]-particleB[j][2]),sx-abs(particleB[i][2]-particleB[j][2]))==abs(particleB[i][2]-particleB[j][2]))
						{
							bx=1.0;
						}
						else
						{
							bx=-1.0;
						}
						
						signx=ax*bx;
					
						if(particleB[i][3]>particleB[j][3])
						{
							ay=1.0;
						}
							else
						{
							ay=-1.0;
						}
							if(Min(abs(particleB[i][3]-particleB[j][3]),sy-abs(particleB[i][3]-particleB[j][3]))==abs(particleB[i][3]-particleB[j][3]))
						{
							by=1.0;
						}
						else
						{
							by=-1.0;
						}
				
						signy=ay*by;

						if(1.2*length>(particleB[i][1]+particleB[j][1]))
							{	
								//����
								particleA[i][4]+=(Vdev(particleB[i],particleB[j],signx,Force,sx,4)/(length*particleB[i][0]))*h;
								particleA[j][4]+=(-Vdev(particleB[i],particleB[j],signx,Force,sx,4)/(length*particleB[j][0]))*h;
											
								//����
							
								particleA[i][5]+=(Vdev(particleB[i],particleB[j],signy,Force,sy,5)/(length*particleB[i][0]))*h;
								particleA[j][5]+=(-Vdev(particleB[i],particleB[j],signy,Force,sy,5)/(length*particleB[j][0]))*h;
							}
					
						
					
						
						else
						{	
							if(particleB[i][1]>particleB[j][1])
							{
								//i��j�̍���
								particleA[i][1]=sqrt(particleA[i][1]*particleA[i][1]+particleA[j][1]*particleA[j][1]);
								//particleA[i][2]=(particleA[i][0]*particleA[i][2]+particleA[j][0]*particleA[j][2])/(particleA[i][0]+particleA[j][0]);
								//particleA[i][3]=(particleA[i][0]*particleA[i][3]+particleA[j][0]*particleA[j][3])/(particleA[i][0]+particleA[j][0]);
								particleA[i][2]+=-signx*particleB[j][0]*(Min(abs(particleB[i][2]-particleB[j][2]),sx-abs(particleB[i][2]-particleB[j][2])))/(particleB[i][0]+particleB[j][0]);
								particleA[i][3]+=-signy*particleB[j][0]*(Min(abs(particleB[i][3]-particleB[j][3]),sx-abs(particleB[i][3]-particleB[j][3])))/(particleB[i][0]+particleB[j][0]);
								particleA[i][4]=(particleA[i][0]*particleA[i][4]+particleA[j][0]*particleA[j][4])/(particleA[i][0]+particleA[j][0]);
								particleA[i][5]=(particleA[i][0]*particleA[i][5]+particleA[j][0]*particleA[j][5])/(particleA[i][0]+particleA[j][0]);
								particleA[i][0]=particleA[i][0]+particleA[j][0];
								//j�̏���
								for(int mn=0;mn<6;mn++)
								{
									particleA[j][mn]=0.0;
								}
							
							}
							else
							{
								//i�Ƃ��̍���
								particleA[j][1]=sqrt(particleA[i][1]*particleA[i][1]+particleA[j][1]*particleA[j][1]);
								//particleA[j][2]=(particleA[i][0]*particleA[i][2]+particleA[j][0]*particleA[j][2])/(particleA[i][0]+particleA[j][0]);
								//particleA[j][3]=(particleA[i][0]*particleA[i][3]+particleA[j][0]*particleA[j][3])/(particleA[i][0]+particleA[j][0]);
								particleA[j][2]+=signx*particleB[i][0]*(Min(abs(particleB[j][2]-particleB[i][2]),sx-abs(particleB[i][2]-particleB[j][2])))/(particleB[i][0]+particleB[j][0]);
								particleA[j][3]+=signy*particleB[i][0]*(Min(abs(particleB[i][3]-particleB[j][3]),sx-abs(particleB[i][3]-particleB[j][3])))/(particleB[i][0]+particleB[j][0]);
								particleA[j][4]=(particleA[i][0]*particleA[i][4]+particleA[j][0]*particleA[j][4])/(particleA[i][0]+particleA[j][0]);
								particleA[j][5]=(particleA[i][0]*particleA[i][5]+particleA[j][0]*particleA[j][5])/(particleA[i][0]+particleA[j][0]);
								particleA[j][0]=particleA[i][0]+particleA[j][0];
								//i�̏���
								for(int mn=0;mn<6;mn++)
								{
									particleA[i][mn]=0.0;
								}
							}
						
				
						}
			
				}
			else{}
			}
		}
	
		for(int q=0;q<kara+1;q++)
		{
			if(particleA[q][0]==0)
			{
				for(int mn=0;mn<6;mn++)
				{
					particleA[q][mn]=particleA[kara][mn];
					particleA[kara][mn]=0;
				}
				kara=kara-1;
			}
			else{}
		}	

}
	else
	{
	for(int i=0;i<kara+1;i++)
		{
			for(int j=i+1;j<kara+1;j++)
				{
					if(particleA[i][0]*particleA[j][0]>0.0)
					{
						double length=distance1(particleB[i][2],particleB[i][3],particleB[j][2],particleB[j][3],sx,sy);//���qi�Ɨ��qj�̋���
						//double length2=distance2(particleB[i][2],particleB[i][3],particleB[j][2],particleB[j][3]);//���qi�Ɨ��q���̌������̋���
						double Force=gravity(length,particleB[i][0],particleB[j][0]);//���qi�Ɨ��qj�̑��ݍ�p��
						double signx,signy;//�͂̌���
						double ax,ay;
						double bx,by;
						if(particleB[i][2]>particleB[j][2])
						{
							ax=1.0;
						}
						else
						{
							ax=-1.0;
						}
						if(Min(abs(particleB[i][2]-particleB[j][2]),sx-abs(particleB[i][2]-particleB[j][2]))==abs(particleB[i][2]-particleB[j][2]))
						{
							bx=1.0;
						}
						else
						{
							bx=-1.0;
						}
						
						signx=ax*bx;
					
						if(particleB[i][3]>particleB[j][3])
						{
							ay=1.0;
						}
							else
						{
							ay=-1.0;
						}
							if(Min(abs(particleB[i][3]-particleB[j][3]),sy-abs(particleB[i][3]-particleB[j][3]))==abs(particleB[i][3]-particleB[j][3]))
						{
							by=1.0;
						}
						else
						{
							by=-1.0;
						}
				
						signy=ay*by;

								//����
								particleA[i][4]+=(Vdev(particleB[i],particleB[j],signx,Force,sx,4)/(length*particleB[i][0]))*h;
								particleA[j][4]+=(-Vdev(particleB[i],particleB[j],signx,Force,sx,4)/(length*particleB[j][0]))*h;
											
								//����
							
								particleA[i][5]+=(Vdev(particleB[i],particleB[j],signy,Force,sy,5)/(length*particleB[i][0]))*h;
								particleA[j][5]+=(-Vdev(particleB[i],particleB[j],signy,Force,sy,5)/(length*particleB[j][0]))*h;
							
						}
				}
		}
						
}
	

	return ;
}



