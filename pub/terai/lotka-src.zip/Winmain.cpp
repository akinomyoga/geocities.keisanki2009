/*#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "MyDirectInput.lib")*/

#define ID_TIMER 12321
#define ID_START 10001
#define ID_STOP 10002
#define ID_INIT 10003
#define ID_SET 10004

#include <windows.h>
#include <iostream>
using namespace std;

//����header file
#include <MyAPIInit.h>
//#include <MyDirectInput.h>
#include <tchar.h>
#include "function.h"
#include "SystemMenu.h"
#include "resource.h"

TCHAR gName[256] = _T("���g�J���H���e(ry");
TCHAR gMenu[256] = _T("IDR_MENU1");

double t = 0.0;
CELL (*CA)[N][N], (*CB)[N][N], (*CC)[N][N];
bool flag = false;

char str_ax[64], str_bx[64], str_cx[64], str_ex[64];
char str_ay[64], str_by[64], str_cy[64], str_ey[64];
char str_az[64], str_bz[64], str_cz[64], str_ez[64];
char str_lap_x[64], str_lap_y[64], str_lap_z[64];

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM); 

LRESULT CALLBACK WndProc(HWND hWnd,  UINT mes, WPARAM wp, LPARAM lp){
	HDC hdc;
	PAINTSTRUCT ps;
	static char str1[64] = "Stop", str2[64] = "Start", str3[64] = "Init", str4[64] = "Setting";
	static char stFi[64] = _T("�f�[�^�t�@�C��(*.dat)\0*.dat\0���ׂẴt�@�C��\0*.*\0\0");
	static char stFn[64], stFt[64], stTitle[64];
	static char InitDir[64] = _T("Data");
	OPENFILENAME ofn;

	static HDC hBufferDC;
	static HBITMAP hBmp;
	static HWND hStop, hStart, hInit, hSet;
	HINSTANCE hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);

	switch(mes){
		case WM_CREATE:
			hStop = CreateWindow("BUTTON", str1, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 4*N+20, 10, 100, 30, hWnd, (HMENU)ID_STOP, hInst, NULL);
			hStart = CreateWindow("BUTTON", str2, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 4*N+20, 50, 100, 30, hWnd, (HMENU)ID_START, hInst, NULL);
			hInit = CreateWindow("BUTTON", str3, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 4*N+20, 90, 100, 30, hWnd, (HMENU)ID_INIT, hInst, NULL);
			hSet = CreateWindow("BUTTON", str4, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 4*N+130, 10, 100, 30, hWnd, (HMENU)ID_SET, hInst, NULL);
			hdc = GetDC(hWnd);
			hBmp = CreateCompatibleBitmap(hdc, 1050, 700);
			hBufferDC = CreateCompatibleDC(hdc);
			SelectObject(hBufferDC, hBmp);
			ReleaseDC(hWnd, hdc);
			return 0;
		case WM_DESTROY:
			DeleteDC(hBufferDC);
			DeleteObject(hBmp);
			PostQuitMessage(0);
			return 0;
		case WM_TIMER:
			RECT rt;
			time_dev(*CA, *CB);
			CC = CA;CA = CB;CB = CC;
			GetClientRect(hWnd, &rt);
			rt.right = 4*N + 15;
			InvalidateRect(hWnd, &rt, FALSE);
			return 0;
		case WM_COMMAND:
			switch(LOWORD(wp)){
				case ID_STOP:
					KillTimer(hWnd, ID_TIMER);
					flag = false;
					return 0;
				case ID_START:
					SetTimer(hWnd, ID_TIMER, 50, NULL);
					flag = true;
					return 0;
				case ID_INIT:
					init(*CA);
					init(*CB);
					GetClientRect(hWnd, &rt);
					rt.right = 4*N + 15;
					InvalidateRect(hWnd, &rt, FALSE);
					return 0;
				case ID_SET:
					DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), hWnd, (DLGPROC)DlgProc);
					return 0;
				case ID_OPEN:
					ZeroMemory(&ofn, sizeof(ofn));
					stFn[0] = '\0';
					sprintf_s(stTitle, 64, _T("�t�@�C�����J���̂ł���B�ɂρ`"));
					if(fileopen(hWnd, &ofn, stFn, stFt, stFi, InitDir, stTitle)){
						if(flag){
							KillTimer(hWnd, ID_TIMER);
							readdata(stFn, *CA, *CB);
							SetTimer(hWnd, ID_TIMER, 50, NULL);
						} else {
							readdata(stFn, *CA, *CB);
						}
					}
					//UpdateWindow(hWnd);
					hdc = GetDC(hWnd);
					hBmp = CreateCompatibleBitmap(hdc, 1050, 700);
					hBufferDC = CreateCompatibleDC(hdc);
					SelectObject(hBufferDC, hBmp);
					ReleaseDC(hWnd, hdc);
					GetClientRect(hWnd, &rt);
					rt.right = 4*N + 15;
					InvalidateRect(hWnd, &rt, FALSE);
					return 0;
				case ID_WRITE:
					ZeroMemory(&ofn, sizeof(ofn));
					stFn[0] = '\0';
					sprintf_s(stTitle, 64, _T("���������A���O��t���ĕۑ�����̂ł�"));
					if(filewrite(hWnd, &ofn, stFn, stFt, stFi, InitDir, stTitle)){
						if(flag){
							KillTimer(hWnd, ID_TIMER);
							writedata(stFn, *CA);
							SetTimer(hWnd, ID_TIMER, 50, NULL);
						} else {
							writedata(stFn, *CA);
						}
					}
					//UpdateWindow(hWnd);
					hdc = GetDC(hWnd);
					hBmp = CreateCompatibleBitmap(hdc, 1050, 700);
					hBufferDC = CreateCompatibleDC(hdc);
					SelectObject(hBufferDC, hBmp);
					ReleaseDC(hWnd, hdc);
					return 0;
				case ID_CLOSE:
					SendMessage(hWnd, WM_DESTROY, 0, 0L);
					return 0;
			}
			return 0;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			Draw(*CB, hdc, hBufferDC, hWnd);
			EndPaint(hWnd, &ps);
			return 0;
		default:
			return DefWindowProc(hWnd, mes, wp, lp);
	}
}

LRESULT CALLBACK DlgProc(HWND hDlg, UINT mes, WPARAM wp, LPARAM lp){
	sprintf_s(str_ax, 64, "%lf", ax);
	sprintf_s(str_bx, 64, "%lf", bx);
	sprintf_s(str_cx, 64, "%lf", cx);
	sprintf_s(str_ex, 64, "%lf", ex);

	sprintf_s(str_ay, 64, "%lf", ay);
	sprintf_s(str_by, 64, "%lf", by);
	sprintf_s(str_cy, 64, "%lf", cy);
	sprintf_s(str_ey, 64, "%lf", ey);

	sprintf_s(str_az, 64, "%lf", az);
	sprintf_s(str_bz, 64, "%lf", bz);
	sprintf_s(str_cz, 64, "%lf", cz);
	sprintf_s(str_ez, 64, "%lf", ez);

	sprintf_s(str_lap_x, 64, "%lf", lap_ax);
	sprintf_s(str_lap_y, 64, "%lf", lap_ay);
	sprintf_s(str_lap_z, 64, "%lf", lap_az);
	switch(mes){
		case WM_INITDIALOG:
			SetDlgItemText(hDlg, IDC_AX, (LPCTSTR)str_ax);
			SetDlgItemText(hDlg, IDC_BX, (LPCTSTR)str_bx);
			SetDlgItemText(hDlg, IDC_CX, (LPCTSTR)str_cx);
			SetDlgItemText(hDlg, IDC_EX, (LPCTSTR)str_ex);

			SetDlgItemText(hDlg, IDC_AY, (LPCTSTR)str_ay);
			SetDlgItemText(hDlg, IDC_BY, (LPCTSTR)str_by);
			SetDlgItemText(hDlg, IDC_CY, (LPCTSTR)str_cy);
			SetDlgItemText(hDlg, IDC_EY, (LPCTSTR)str_ey);

			SetDlgItemText(hDlg, IDC_AZ, (LPCTSTR)str_az);
			SetDlgItemText(hDlg, IDC_BZ, (LPCTSTR)str_bz);
			SetDlgItemText(hDlg, IDC_CZ, (LPCTSTR)str_cz);
			SetDlgItemText(hDlg, IDC_EZ, (LPCTSTR)str_ez);

			SetDlgItemText(hDlg, IDC_LAP_X, (LPCTSTR)str_lap_x);
			SetDlgItemText(hDlg, IDC_LAP_Y, (LPCTSTR)str_lap_y);
			SetDlgItemText(hDlg, IDC_LAP_Z, (LPCTSTR)str_lap_z);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wp)){
				case IDOK:
					GetDlgItemText(hDlg, IDC_AX, (LPTSTR)str_ax, sizeof(str_ax));
					GetDlgItemText(hDlg, IDC_BX, (LPTSTR)str_bx, sizeof(str_bx));
					GetDlgItemText(hDlg, IDC_CX, (LPTSTR)str_cx, sizeof(str_cx));
					GetDlgItemText(hDlg, IDC_EX, (LPTSTR)str_ex, sizeof(str_ex));

					GetDlgItemText(hDlg, IDC_AY, (LPTSTR)str_ay, sizeof(str_ay));
					GetDlgItemText(hDlg, IDC_BY, (LPTSTR)str_by, sizeof(str_by));
					GetDlgItemText(hDlg, IDC_CY, (LPTSTR)str_cy, sizeof(str_cy));
					GetDlgItemText(hDlg, IDC_EY, (LPTSTR)str_ey, sizeof(str_ey));

					GetDlgItemText(hDlg, IDC_AZ, (LPTSTR)str_az, sizeof(str_az));
					GetDlgItemText(hDlg, IDC_BZ, (LPTSTR)str_bz, sizeof(str_bz));
					GetDlgItemText(hDlg, IDC_CZ, (LPTSTR)str_cz, sizeof(str_cz));
					GetDlgItemText(hDlg, IDC_EZ, (LPTSTR)str_ez, sizeof(str_ez));

					GetDlgItemText(hDlg, IDC_LAP_X, (LPTSTR)str_lap_x, sizeof(str_lap_x));
					GetDlgItemText(hDlg, IDC_LAP_Y, (LPTSTR)str_lap_y, sizeof(str_lap_y));
					GetDlgItemText(hDlg, IDC_LAP_Z, (LPTSTR)str_lap_z, sizeof(str_lap_z));

					ax = atof(str_ax);bx = atof(str_bx);cx = atof(str_cx);ex = atof(str_ex);
					ay = atof(str_ay);by = atof(str_by);cy = atof(str_cy);ey = atof(str_ey);
					az = atof(str_az);bz = atof(str_bz);cz = atof(str_cz);ez = atof(str_ez);
					lap_ax = atof(str_lap_x);lap_ay = atof(str_lap_y);lap_az = atof(str_lap_z);

					EndDialog(hDlg, IDOK);
					break;
				case IDCANCEL:
					EndDialog(hDlg, IDCANCEL);
					break;
			}
			return FALSE;
		default:
			return FALSE;
	}
	return TRUE;
}

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR llpCmdLine, int nCmdShow){
	MSG msg;
	HWND hWnd;
	WNDCLASSEX wcex;

	//������
	init(C);
	init(BC);
	CA = &C;
	CB = &BC;
	
	//�A�v���P�[�V�����̏�����
	if(!MyAPIInit(&hWnd, hInstance, &wcex, gName, gMenu, MAKEINTRESOURCE(IDI_ICON1), WndProc)){
		return 0;
	}


	ShowWindow(hWnd, nCmdShow);

	//DirectInput�̏�����
	/*MyInput.init(hInstance);
	MyInput.KeyBoard_init(hWnd);*/
	


	do{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)){
			DispatchMessage(&msg);
		}
	}while(msg.message != WM_QUIT);

	//MyInput.Release();


	return 0;
}