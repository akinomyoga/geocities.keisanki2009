#pragma once

int MyAPIInit(HWND* phWnd ,HINSTANCE hInstance, WNDCLASSEX* pwcex,LPCTSTR gName, LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM)){
	(*pwcex).cbClsExtra = 0;
	(*pwcex).cbSize = sizeof(WNDCLASSEX);
	(*pwcex).cbWndExtra = 0;
	(*pwcex).hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	(*pwcex).hCursor = NULL;
	(*pwcex).hIcon = NULL;
	(*pwcex).hIconSm = NULL;
	(*pwcex).hInstance = hInstance;
	(*pwcex).lpfnWndProc = WndProc;
	(*pwcex).lpszClassName = gName;
	(*pwcex).lpszMenuName = NULL;
	(*pwcex).style = (CS_HREDRAW | CS_VREDRAW);

	if(!RegisterClassEx(pwcex)){
		return 0;
	}

	if( !(*phWnd = CreateWindow(gName, gName, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL)) ){
		return 0;
	}

	return 1;
}

int MyAPIInit(HWND* phWnd ,HINSTANCE hInstance, WNDCLASSEX* pwcex,LPCTSTR gName, LPCTSTR gMenu, LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM)){
	(*pwcex).cbClsExtra = 0;
	(*pwcex).cbSize = sizeof(WNDCLASSEX);
	(*pwcex).cbWndExtra = 0;
	(*pwcex).hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	(*pwcex).hCursor = NULL;
	(*pwcex).hIcon = NULL;
	(*pwcex).hIconSm = NULL;
	(*pwcex).hInstance = hInstance;
	(*pwcex).lpfnWndProc = WndProc;
	(*pwcex).lpszClassName = gName;
	(*pwcex).lpszMenuName = gMenu;
	(*pwcex).style = (CS_HREDRAW | CS_VREDRAW);

	if(!RegisterClassEx(pwcex)){
		return 0;
	}

	if( !(*phWnd = CreateWindow(gName, gName, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL)) ){
		return 0;
	}

	return 1;
}