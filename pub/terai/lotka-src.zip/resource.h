//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Dialog.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       104
#define IDC_AX                          1001
#define IDC_BX                          1002
#define IDC_CX                          1003
#define IDC_EX                          1004
#define IDC_AY                          1005
#define IDC_BY                          1006
#define IDC_CY                          1007
#define IDC_EY                          1008
#define IDC_AZ                          1009
#define IDC_BZ                          1010
#define IDC_CZ                          1011
#define IDC_EZ                          1012
#define IDC_LAP_X                       1013
#define IDC_LAP_Y                       1014
#define IDC_LAP_Z                       1015
#define ID_OPEN                         40004
#define ID_WRITE                        40005
#define ID_CLOSE                        40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
