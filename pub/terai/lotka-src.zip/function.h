#pragma once
#define _USE_MATH_DEFINES
#include <math.h>
const int N = 100;
class CELL{
public:
	double x, y, z;

	CELL(){};
	CELL(double x, double y, double z){
		this->x = x;
		this->y = y;
		this->z = z;
	}
	
	CELL operator + (const CELL& C){
		CELL C1;
		C1.x = this->x + C.x;
		C1.y = this->y + C.y;
		C1.z = this->z + C.z;
		return C1;
	}

	CELL& operator = (const CELL& C){
		this->x = C.x;
		this->y = C.y;
		this->z = C.z;
		return *this;
	}
};


CELL BC[N][N], C[N][N];
double dt = 0.01;
double dx = 1.0, dy = 1.0;
double ax = -1.0, bx = 3.0, cx = 2.0, ex = 0.0;
double ay = -1.0, by = 2.0, cy = 1.0, ey = -2.0;
double az = 10.0, bz = 2.0, cz = 0.0, ez = 1.0;
double lap_ax = 1.0, lap_ay = 1.0, lap_az = 0.1;
double xi = 1.0, yi = 1.0, zi = 1.0;
const double Max = 10.0;

inline double fx(double x, double y, double z, double t){
	return ax*x*(bx  - cx*y - ex*z);
}

inline double fy(double y, double z, double x, double t){
	return ay*y*(by - cy*z - ey*x);
}

inline double fz(double z, double x, double y, double t){
	return az*z*(bz - cz*x - ez*y);
}

inline CELL Heun3deg(const CELL (&BC)[N][N], double t, double (*fx)(double, double, double, double), double (*fy)(double, double, double, double), double (*fz)(double, double, double, double), double h, int i, int j){
#define kx1     (h*fx(BC[i][j].x, BC[i][j].y, BC[i][j].z, t))
#define kx2     (h*fx(BC[i][j].x+kx1/3.0, BC[i][j].y+kx1/3.0, BC[i][j].z+kx1/3.0, t+h/3.0))
#define kx3     (h*fx(BC[i][j].x+2.0*kx2/3.0, BC[i][j].y+2.0*kx2/3.0, BC[i][j].z+2.0*kx2/3.0, t+2.0*h/3.0))
#define ky1     (h*fy(BC[i][j].y, BC[i][j].z, BC[i][j].x, t))
#define ky2     (h*fy(BC[i][j].y+ky1/3.0, BC[i][j].z+ky1/3.0, BC[i][j].x+ky1/3.0, t+h/3.0))
#define ky3     (h*fy(BC[i][j].y+2.0*ky2/3.0, BC[i][j].z+2.0*ky2/3.0, BC[i][j].x+2.0*ky2/3.0, t+2.0*h/3.0))
#define kz1     (h*fz(BC[i][j].z, BC[i][j].x, BC[i][j].y, t))
#define kz2     (h*fz(BC[i][j].z+kz1/3.0, BC[i][j].x+kz1/3.0, BC[i][j].y+kz1/3.0, t+h/3.0))
#define kz3     (h*fz(BC[i][j].z+2.0*kz2/3.0, BC[i][j].x+2.0*kz2/3.0, BC[i][j].y+2.0*kz2/3.0, t+2.0*h/3.0))
	CELL DEV;
	DEV.x = (kx1+3.0*kx3)/4.0;
	DEV.y = (ky1+3.0*ky3)/4.0;
	DEV.z = (kz1+3.0*kz3)/4.0;
	return DEV;
#undef kx1
#undef kx2
#undef kx3
#undef ky1
#undef ky2
#undef ky3
#undef kz1
#undef kz2
#undef kz3
}

inline void time_dev(CELL (&C)[N][N], CELL (&BC)[N][N]){
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
#define j (j+N)
#define i (i+N)
			double lap_x = (BC[(i+1)%N][j%N].x + BC[(i-1)%N][j%N].x - 2.0*BC[i%N][j%N].x)/dx/dx + (BC[i%N][(j+1)%N].x + BC[i%N][(j-1)%N].x - 2.0*BC[i%N][j%N].x)/dy/dy;
			double lap_y = (BC[(i+1)%N][j%N].y + BC[(i-1)%N][j%N].y - 2.0*BC[i%N][j%N].y)/dx/dx + (BC[i%N][(j+1)%N].y + BC[i%N][(j-1)%N].y - 2.0*BC[i%N][j%N].y)/dy/dy;
			double lap_z = (BC[(i+1)%N][j%N].z + BC[(i-1)%N][j%N].z - 2.0*BC[i%N][j%N].z)/dx/dx + (BC[i%N][(j+1)%N].z + BC[i%N][(j-1)%N].z - 2.0*BC[i%N][j%N].z)/dy/dy;
#undef i
#undef j
			CELL Lap(dt*lap_ax*lap_x, dt*lap_ay*lap_y, dt*lap_az*lap_z/*0*/);
			C[i%N][j%N] = C[i%N][j%N] + Heun3deg(BC, 0, fx, fy, fz, dt, i%N, j%N) + Lap;
			if(C[i%N][j%N].x > Max){ C[i%N][j%N].x = Max;}
			if(C[i%N][j%N].y > Max){ C[i%N][j%N].y = Max;}
			if(C[i%N][j%N].z > Max){ C[i%N][j%N].z = Max;}
			if(C[i%N][j%N].x < 0.0){ C[i%N][j%N].x = 0.0;}
			if(C[i%N][j%N].y < 0.0){ C[i%N][j%N].y = 0.0;}
			if(C[i%N][j%N].z < 0.0){ C[i%N][j%N].z = 0.0;}
		}
	}
}

inline void Draw(CELL (&C)[N][N], HDC hdc, HDC hBuffer, HWND hWnd){
	RECT rt, rt1, rt2, rt3;
	GetClientRect(hWnd, &rt);
	FillRect(hBuffer, &rt, (HBRUSH)GetStockObject(WHITE_BRUSH));

	rt1.bottom = 2;rt1.top = 0;
	rt2.bottom = 2;rt2.top = 0;
	rt3.bottom = 2*N + 12;rt3.top = rt3.bottom - 2;

	/*char str1[64] = "����̓l�R����(���H)�Ȃ̂ł���B", str2[64] = "�E��̓V�}�E�}(���H)�Ȃ̂ł��A�����B", str3[64] = "�����̂̓u���E�E�E�J���t�����[�i�A���j�ł����B";

	TextOut(hBuffer, N*2 +10, N*2+10, str1, strlen(str1));
	TextOut(hBuffer, N*2 +10, N*2+30, str2, strlen(str2));
	TextOut(hBuffer, N*2 +10, N*2+50, str3, strlen(str3));*/

	for(int i = 0; i < N; i++, rt1.top += 2, rt1.bottom += 2, rt2.top += 2, rt2.bottom += 2, rt3.top += 2, rt3.bottom += 2){
		rt1.left = 0;rt1.right = 2;
		rt2.left = 2*N + 10;rt2.right = rt2.left + 2;
		rt3.left = 0;rt3.right = 2;
		for(int j = 0; j < N; j++, rt1.left += 2, rt1.right += 2, rt2.left += 2, rt2.right += 2, rt3.left += 2, rt3.right += 2){
			HBRUSH hBrush, hOldBrush;

			hBrush = (HBRUSH)CreateSolidBrush(RGB((int)(255/Max*C[i][j].x), 0, 0));
			hOldBrush = (HBRUSH)SelectObject(hBuffer, hBrush);
			FillRect(hBuffer, &rt1, hBrush);
			SelectObject(hBuffer, hOldBrush);
			DeleteObject(hBrush);

			hBrush = (HBRUSH)CreateSolidBrush(RGB(0, 0, (int)(255/Max*C[i][j].y)));
			hOldBrush = (HBRUSH)SelectObject(hBuffer, hBrush);
			FillRect(hBuffer, &rt2, hBrush);
			SelectObject(hdc, hOldBrush);
			DeleteObject(hBrush);

			hBrush = (HBRUSH)CreateSolidBrush(RGB(0, (int)(255/Max*C[i][j].z), 0));
			hOldBrush = (HBRUSH)SelectObject(hBuffer, hBrush);
			FillRect(hBuffer, &rt3, hBrush);
			SelectObject(hBuffer, hOldBrush);
			SelectObject(hBuffer, hOldBrush);
			DeleteObject(hBrush);
		}
	}

	BitBlt(hdc, rt.left, rt.top, rt.right, rt.bottom, hBuffer, 0, 0, SRCCOPY);
}

void init(CELL (&C)[N][N]){
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			//*
			C[i][j].x = xi + xi/Max*cos((double)(i+j)*M_PI*2.0)*exp(-(double)(i*j));
			C[i][j].y = yi + yi/Max*sin((double)(i*j)*M_PI*2.0)*exp(-(double)(i+j));
			/*/
			if(i == N/2 + 1 && j == N/2 + 1){
				C[i][j].x = xi;
			} else {
				C[i][j].x = xi/10.0;
			}
			if(i == (int)(N/2) && j == (int)(N/2)){
				C[i][j].y = yi;
			} else {
				C[i][j].y = yi/10.0;
			}//*/
			C[i][j].z = zi + zi/Max*exp(-(double)(i+j));
		}
	}
}