#pragma once
#include <windows.h>
#include <fstream>
#include <Cderr.h>
#include <iostream>
//using namespace std;

inline bool fileopen(HWND hWnd, OPENFILENAME* ofn, char* stFn, char* stFt, char* stFi, char* inDir, char* stTitle){
	ofn->lStructSize = sizeof(OPENFILENAME);
	ofn->hwndOwner = hWnd;
	ofn->lpstrFilter = stFi;
	ofn->lpstrCustomFilter = NULL;
	ofn->nMaxCustFilter = 0;
	ofn->nFilterIndex = 1;
	ofn->lpstrFile = stFn;
	ofn->nMaxFile = 255;
	ofn->lpstrFileTitle = stFt;
	ofn->nMaxFileTitle = 255;
	ofn->lpstrInitialDir = inDir;
	ofn->lpstrTitle = stTitle;
	ofn->Flags = OFN_FILEMUSTEXIST;
	ofn->nFileOffset = 0;
	ofn->lpstrDefExt = NULL;
	ofn->lCustData = 0;
	ofn->lpfnHook = NULL;
	ofn->lpTemplateName = NULL;

	if(!GetOpenFileName(ofn)){
		long error = 0;
		error = CommDlgExtendedError();
		if(error == CDERR_GENERALCODES){
			return false;
		}
		char strerr[64];
		sprintf_s(strerr, 64, "�_�C�A���O�{�b�N�X�Ăяo���G���[ | code:%x", error);
		MessageBox(hWnd, (LPCTSTR)strerr, (LPCTSTR)"�G���[", MB_OK);
		return false;
	}

	return true;
}

inline bool filewrite(HWND hWnd, OPENFILENAME* ofn, char* stFn, char* stFt, char* stFi, char* inDir, char* stTitle){
	ofn->lStructSize = sizeof(OPENFILENAME);
	ofn->hwndOwner = hWnd;
	ofn->lpstrFilter = stFi;
	ofn->lpstrCustomFilter = NULL;
	ofn->nMaxCustFilter = 0;
	ofn->nFilterIndex = 1;
	ofn->lpstrFile = stFn;
	ofn->nMaxFile = 255;
	ofn->lpstrFileTitle = stFt;
	ofn->nMaxFileTitle = 255;
	ofn->lpstrInitialDir = inDir;
	ofn->lpstrTitle = stTitle;
	ofn->Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;
	ofn->nFileOffset = 0;
	ofn->lpstrDefExt = NULL;
	ofn->lCustData = 0;
	ofn->lpfnHook = NULL;
	ofn->lpTemplateName = NULL;

	if(!GetSaveFileName(ofn)){
		long error = 0;
		error = CommDlgExtendedError();
		if(error == CDERR_GENERALCODES){
			return false;
		}
		char strerr[64];
		sprintf_s(strerr, 64, "�_�C�A���O�{�b�N�X�Ăяo���G���[ | code:%x", error);
		MessageBox(hWnd, (LPCTSTR)strerr, (LPCTSTR)"�G���[", MB_OK);
		return false;
	}
	return true;
}


inline bool readdata(char* file_name, CELL (&C)[N][N], CELL (&BC)[N][N]){
	std::ifstream input_file(file_name);
	input_file>>ax>>bx>>cx>>ex;
	input_file>>ay>>by>>cy>>ey;
	input_file>>az>>bz>>cz>>ez;
	input_file>>lap_ax>>lap_ay>>lap_az;

	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			input_file>>C[i][j].x>>C[i][j].y>>C[i][j].z;
			BC[i][j] = C[i][j];
		}
	}
	input_file.close();
	return true;
}

inline bool writedata(char* file_name, CELL (&C)[N][N]){
	std::ofstream out_file(file_name);
	char str1[128], str2[128], str3[128], str4[128];
	sprintf_s(str1, 128, "%.16e	%.16e	%.16e	%.16e", ax, bx, cx, ex);
	sprintf_s(str2, 128, "%.16e	%.16e	%.16e	%.16e", ay, by, cy, ey);
	sprintf_s(str3, 128, "%.16e	%.16e	%.16e	%.16e", az, bz, cz, ez);
	sprintf_s(str4, 128, "%.16e	%.16e	%.16e", lap_ax, lap_ay, lap_az);
	out_file<<str1<<std::endl<<str2<<std::endl<<str3<<std::endl<<str4<<std::endl;
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			char str[128];
			sprintf_s(str, 128, "%.16e	%.16e	%.16e", C[i][j].x, C[i][j].y, C[i][j].z);
			out_file<<str<<std::endl;
		}
	}
	out_file.close();
	return true;
}