#include <iostream>
#include <cmath>

//logistic map x_{n+1}=4rx_{n}(1-x_{n})�ɂ��Ē��ׂ�

double logistic(double x,double r);

int main(){
	const int M = 1000;
	const double d = 1.0/(double)M;
	const double epsilon = 0.001;
	double r;
	int cycle;
	
	int N = 5000;
	double x;
	for(int i=1 ; i< M ; i++){
		r = d*i;

		double y=0.5;
		for(int j=1; j<N ; j++){
			y = logistic(y,r);
		}
		x = y;
		for(int k=1; k<500 ; k++){
			x = logistic(x,r);
			if(fabs(x-y)<epsilon){
				cycle = k;
				break;
			}
			cycle = 500;
		}
		std::cout<<r<<" "<<cycle<<std::endl;
	}

	return EXIT_SUCCESS;
}

double logistic(double x,double r){
	return 4*r*x*(1-x);
}