#include <iostream>
#include <cmath>

double phi0(double x,double h);
double phi1(double x,double h);

int main(){
	const double pi = 3.14159265358979;

	const int N = 10;
	double h = 1.0/(double) N;
	int n;
	double x[N+2];

	double f[N+1]; //�����̒l���o����
	double df[N+1]; //�����̔����̒l���o����D

	std::cout<<"sin(n*pi*x)��n�̒l�����"<<std::endl;
	std::cin>>n;

	for(int i=0 ; i<= N+1 ; i++)
		x[i]=i*h;

	for(int i = 0 ; i<= N ; i++){
		f[i] = sin(n*pi*x[i]);
		df[i]= (sin(n*pi*x[i+1])-sin(n*pi*x[i-1]))/(n*pi*x[i+1]-x[i-1]);
	}

	for(int i=1; i<2*N+1 ; i++){
		double y = i*h/2; //���ׂ�x�̒l
		int k=0;
		for(int j=1; j<= N+1; j++){
			if(y < x[j]){
				k = j;
				break;
			}
		}
		double g = f[k-1]*phi0(n*pi*y-n*pi*x[k-1],n*pi*h)+df[k-1]*phi1(n*pi*y-n*pi*x[k-1],n*pi*h)
					+f[k]*phi0(n*pi*y-n*pi*x[k],n*pi*h) + df[k]*phi1(n*pi*y-n*pi*x[k],n*pi*h);
		std::cout<<n*pi*y<<" "<<(g-sin(n*pi*y))*(g-sin(n*pi*y))<<std::endl;
	}
}

double phi0(double x, double h){
	return 1.0 - (3.0/(h*h))*x*x +(2.0/(h*h*h))*fabs(x)*x*x;
}

double phi1(double x, double h){
	return x-(2.0/h)*x*fabs(x)+(1.0/(h*h*h))*x*x*x;
}