inline void Heun3deg(double& x, double& t, double (*f)(double x, double t), double h){
	double k1=h*f(x,t);
	double k2=h*f(x+k1/3.0,t+h/3.0);
	double k3=h*f(x+k2*2.0/3.0,t+h*2.0/3.0);
	x+=(k1+3.0*k3)/4.0;
	t+=h;
	return;
}