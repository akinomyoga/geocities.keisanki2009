#include "Heun3deg.h"
#include <cmath>
#include <fstream>
using namespace std;

double f1(double x, double t){
	return 2.0*t-1.0;
}

double f2(double x, double t){
	return 3.0*t*t-1.0;
}

double f3(double x, double t){
	return 4.0*t*t*t-1.0;
}

double f4(double x, double t){
	return x;
}

int main(){
	ofstream out("output1-2.txt");
	int n=1;
	out<<"# ������ x(1)�𐔒l�v�Z�����l x(1)�̌덷�̐�Βl"<<endl;
	out<<"# No.0 dx/dt=2t-1, x(0)=0"<<endl;
	for(int i=0;i<25;i++){
		double x=0,t=0;
		double h=1.0/n;
		for(int j=0;j<n;j++) Heun3deg(x,t,f1,h);
		out<<n<<" "<<x<<" "<<fabs(x)<<endl;
		n*=2;
	}
	out<<endl<<endl;
	n=1;
	out<<"# No.1 dx/dt=3t^2-1, x(0)=0"<<endl;
	for(int i=0;i<25;i++){
		double x=0,t=0;
		double h=1.0/n;
		for(int j=0;j<n;j++) Heun3deg(x,t,f2,h);
		out<<n<<" "<<x<<" "<<fabs(x)<<endl;
		n*=2;
	}
	out<<endl<<endl;
	n=1;
	out<<"# No.2 dx/dt=4t^3-1, x(0)=0"<<endl;
	for(int i=0;i<25;i++){
		double x=0,t=0;
		double h=1.0/n;
		for(int j=0;j<n;j++) Heun3deg(x,t,f3,h);
		out<<n<<" "<<x<<" "<<fabs(x)<<endl;
		n*=2;
	}
	out<<endl<<endl;
	n=1;
	out<<"# No.3 dx/dt=x, x(0)=1"<<endl;
	for(int i=0;i<25;i++){
		double x=1.0,t=0;
		double h=1.0/n;
		for(int j=0;j<n;j++) Heun3deg(x,t,f4,h);
		out<<n<<" "<<x<<" "<<fabs(x-2.718281828459045)<<endl;
		n*=2;
	}
	return 0;
}
