#include <iostream>
#include <cmath>
#include "Heun3deg.h"

double v(double x,double t);
double h(double x);
double g(double x);

int main(){
	const int N = 10000;
	double x[N+1];
	double t[N+1];
	x[0]=0.01;
	t[0]=0;

	double h= 10.0/(double)N;

	for(int i=1; i<N+1 ; i++){
		double y=x[i-1];
		double s=t[i-1];
		Heun3deg(y,s,v,h);
		x[i]=y;
		t[i]=s;
	}

	for(int i=1; i<N+1 ;i++){
		double y=x[i-1];
		double s=t[i-1];
		std::cout<<s<<" "<<v(y,s)<<std::endl;
	}
}

double v(double x,double t){
	return sqrt(-h(x)/(g(x)*g(x)+1));
}
double h(double x){
	const double pi = 3.1415265358979323;
	return -0.25*x-(1.0-cos(pi*x));
}
double g(double x){
	double d = 0.001;
	return (h(x+0.5*d)-h(x-0.5*d))/d;
}