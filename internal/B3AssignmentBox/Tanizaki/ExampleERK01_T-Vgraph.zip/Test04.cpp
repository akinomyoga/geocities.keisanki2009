#include <iostream>
#include "Heun3deg.h"

double f(double x,double t); //�ʒu�̎��Ԕ���

int main(){
	const int N = 10000;
	double x,t;
	double h = 1.0/(double)N;
	double y[N+1];
	double s[N+1];
	y[0] = 1.0; //��������
	s[0] = 0;

	for(int i=1 ; i<N+1 ; i++){
		x=y[i-1];
		t=s[i-1];
		Heun3deg(x,t,f,h);
		y[i]=x;
		s[i]=t;
	}

	for(int i=0 ; i<=N ; i++){
		std::cout<<s[i]<<" "<<y[i]<<std::endl;
	}
}

double f(double x,double t){
	return x;
}