#include <iostream>
#include "Heun3deg.h"

double f(double x,double t); //�ʒu�̎��Ԕ���

int main(){
	const int N = 10000;
	double x=0,y=0,t=0,s=0;
	double h = 1.0/(double)N;

	for(int i=1 ; i<N+1 ; i++){
		x=y;
		t=s;
		Heun3deg(x,t,f,h);
		y=x;
		s=t;
	}

	std::cout<<"x = "<<y<<" at t="<<s<<std::endl;
}

double f(double x,double t){
	return 2.0*t-1.0;
}