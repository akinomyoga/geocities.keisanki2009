#pragma once

inline double CIP0(double x, double a, double h){
	if(x <= a+h && x >= a-h){
		return 1.0 - 3.0*(x-a)*(x-a)/h/h + 2.0*fabs(x-a)*(x-a)*(x-a)/h/h/h;
	} else {
		return 0.0;
	}
}

inline double CIP1(double x, double a, double h){
	if(x <= a+h && x >= a-h){
	return (x-a) - 2.0*fabs(x-a)*(x-a)/h + (x-a)*(x-a)*(x-a)/h/h;
	} else {
		return 0.0;
	}
}