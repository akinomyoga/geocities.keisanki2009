#pragma once

inline double Liner(double x, double a, double h){
	if(x <= a+h && x >= a-h){
		return -fabs(x-a)/h + 1;
	} else {
		return 0.0;
	}
}