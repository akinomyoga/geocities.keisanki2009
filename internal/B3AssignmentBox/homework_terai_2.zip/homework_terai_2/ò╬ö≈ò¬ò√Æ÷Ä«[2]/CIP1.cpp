#include <iostream>
#define _USE_MATH_DEFINES
#include <cmath>
#include "CIP.h"
#include "Liner.h"

const int N = 101;
const int M = 1001;

int main(){
	double s0[N], s1[N];
	double n = 100.0;
	double h = 1.0/((double)N-1.0);
	for(int i = 0; i < N; i++){
		s0[i] = sin(n*M_PI*(double)i/((double)N-1.0));
		s1[i] = n*M_PI*cos(n*M_PI*(double)i/((double)N-1.0));
	}
	double x[M], y[M];
	double H = 1.0/((double)M-1.0);
	for(int i = 0; i < M; i++){
		int L1 = 0, L2 = 1;
		double x1 = 0.0, x2 = h;
		while(1){//x���ǂ��ɂ���̂��𔻒f�B
			if(x1 <= H*(double)i && H*(double)i <= x2){
				break;
			}
			x1 += h;
			x2 += h;
			L1 += 1;
			L2 += 1;
		}
		x[i] = s0[L1]*CIP0((double)i*H, x1, h) + s1[L1]*CIP1((double)i*H, x1, h)
				+ s0[L2]*CIP0((double)i*H, x2, h) + s1[L2]*CIP1((double)i*H, x2, h);

		y[i] = s0[L1]*Liner((double)i*H, x1, h) + s0[L2]*Liner((double)i*H, x2, h);
	}
	std::cout<<"#Data0 CIP"<<std::endl;
	for(int i = 0; i < M; i++){
		std::cout<<(double)i*H<<"	"<<fabs(x[i] - sin(n*M_PI*(double)i*H))<<std::endl;
	}
	std::cout<<std::endl<<std::endl;
	std::cout<<"#Data1 Liner"<<std::endl;
	for(int i = 0; i < M; i++){
		std::cout<<(double)i*H<<"	"<<fabs(y[i] - sin(n*M_PI*(double)i*H))<<std::endl;
	}
	return 0;
}