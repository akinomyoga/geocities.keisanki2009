#include <iostream>
using namespace std;

const int N = 1024;//���_�ŕ��ς��Ƃ邩�B
const int M = 107;//���_�Ƃ邩

inline void time_dev(double &, double &, double);//���Ԕ��W�֐�
inline void init(double &);//�������֐��i���͂���Ȃ����j
double average(double x[M][N], int i);

int main(){
	double dr = 0.001;
	double r = 0.892;
	double u = 0.5;
	double x[M][N];
	for(int k = 0; k < M; k++){
		r += dr;
		u = 0.5;
		for(int n = 0; n < 10000; n++){
			time_dev(u, u, r);
		}
		for(int n = 0; n < N; n++){
			time_dev(u, u, r);
			x[k][n] = u;
		}
	}
	r = 0.892;
	for(int k = 0; k < M; k++){
		r += dr;
		cout<<r<<"	"<<average(x, k)<<endl;
	}
	return 0;
}

inline void time_dev(double &a, double &b, double r){
	b = 4.0*r*a*(1.0 - a);
	return;
}

inline void init(double &a){
	a = 0.5;
	return;
}

double average(double x[M][N], int i){
	double s = 0.0;
	for(int k = 0; k < N; k++){
		s += x[i][k];
	}
	return s/(double)N;
}