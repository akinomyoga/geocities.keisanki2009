#include <iostream>
using namespace std;

const int N = 20;//�U�����n�߂Ă��牽�_��邩�B

inline void time_dev(double &, double &, double);//���Ԕ��W�֐�
inline void init(double &);//�������֐��i���͂���Ȃ����j

int main(){
	double dr = 0.0001;
	double Time = 10000;
	double r = 0.892;
	double u = 0.5;
	double x[12][N];
	/*for(int k = 0; k < N; k++){//������
		init(x[k]);
	}*/
	for(int k = 0; k < 12; k++){
		r += dr;
		u = 0.5;
		for(int n = 0; n < 10000; n++){
			time_dev(u, u, r);
		}
		for(int n = 0; n < N; n++){
			time_dev(u, u, r);
			x[k][n] = u;
		}
	}
	r = 0.892;
	for(int k = 0; k < 12; k++){
		Time = 10000;
		r += dr;
		cout<<"#Data"<<k<<"(r="<<r<<")"<<endl;
		for(int n = 0; n < N; n++){//�o��
			Time += 1.0;
			cout<<Time<<"	"<<x[k][n]<<endl;
		}
		cout<<endl;
		cout<<endl;
	}
	return 0;
}

inline void time_dev(double &a, double &b, double r){
	b = 4.0*r*a*(1.0 - a);
	return;
}

inline void init(double &a){
	a = 0.5;
	return;
}