#include <iostream>
#include <cmath>
using namespace std;

const int N = 1024;//���_�ŕ��ς��Ƃ邩�B
const int M = 29;//r�����_�Ƃ邩

inline void time_dev(double &, double &, double);//���Ԕ��W�֐�
inline void init(double &);//�������֐��i���͂���Ȃ����j


int main(){
	double dr = 0.001;
	double r = 0.97;
	double u, v;
	double x[M];
	int I = 0;
	for(int k = 0; k < M; k++){
		r += dr;
		u = r + dr/10000000000000.0;
		v = r - dr/10000000000000.0;
		while(1){
			time_dev(u, u, r);
			time_dev(v, v, r);
			I++;
			//cout<<fabs((u-v)/u)<<"	"<<u<<"	"<<v<<endl;
			if(fabs((u-v)/u) > 0.1)
				break;
		}
		//cout<<I<<endl;
		x[k] = I;
		I = 0;
	}
	r = 0.97;
	for(int k = 0; k < M; k++){
		r += dr;
		cout<<r<<"	"<<x[k]<<endl;
	}
	return 0;
}

inline void time_dev(double &a, double &b, double r){
	b = 4.0*r*a*(1.0 - a);
	return;
}

inline void init(double &a){
	a = 0.5;
	return;
}