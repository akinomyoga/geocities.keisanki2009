#include <iostream>
using namespace std;

const int N = 16;//����
const int M = 12;//���_�Ƃ邩

inline void time_dev(double &, double &, double);//���Ԕ��W�֐�
inline void init(double &);//�������֐��i���͂���Ȃ����j

int main(){
	double dr = 0.0001;
	double r = 0.8909;
	double u = 0.5;
	double x[M][N];
	for(int k = 0; k < M; k++){
		r += dr;
		u = 0.5;
		for(int n = 0; n < 10000; n++){
			time_dev(u, u, r);
		}
		for(int n = 0; n < N; n++){
			time_dev(u, u, r);
			x[k][n] = u;
		}
	}
	for(int k = 0; k < N; k++){
		r = 0.8909;
		cout<<"#Data"<<k<<endl;
		for(int n = 0; n < M; n++){//�o��
			r += dr;
			cout<<r<<"	"<<x[n][k]<<endl;
		}
		cout<<endl;
		cout<<endl;
	}
	return 0;
}

inline void time_dev(double &a, double &b, double r){
	b = 4.0*r*a*(1.0 - a);
	return;
}

inline void init(double &a){
	a = 0.5;
	return;
}