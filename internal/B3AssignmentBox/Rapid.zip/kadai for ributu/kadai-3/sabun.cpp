#include<iostream>
#include<fstream>
#include<cmath.h>
using namespace std;

double ssin(double x){
	return sin(acos(-1)*x);
}

void sabun(double(*g)(double x),double L,int xN,int tN,double dt){
	ofstream f("sabun.txt");
	double *y;
	double z1,z2;
	z1=0;
	z2=0;
	y = new double[xN+1];
	
	double c=L*dt*(double)xN*(double)xN;
	for(int i=0;i<xN+1;i++){
		y[i]=g((double)i/(double)xN);//�����l���Z�b�g
		
		
		
	}

		y[0]=0;
		y[xN]=0;//���E�����ŗ��[��0
	
	for(int i=0;i<tN;i++){
		z1=0;
		z2=0;
		
		for(int j=1;j<xN;j++){
			z1=y[j];
			y[j]=y[j]+c*(y[j+1]-2*y[j]+z2);
		
			z2=z1;
		}
		
		
		
	}
	for(int i=0;i<xN;i++){
		f << (double)i/(double)xN<<" "<< y[i] << endl; 
	}

	

}

int main(){
	
	sabun(ssin,0.003,100,100,0.01);
	


	return 0;
}