#include<iostream>
#include<fstream>
using namespace std;

double func1(double x,double t){
	return 2*t-1;
}
double func2(double x,double t){
	return 3*t*t-1;
}
double func3(double x,double t){
	return 4*t*t*t-1;
}
double func4(double x,double t){
	return x;
}





double Heun(double &x,double &t,double (*f)(double x, double t),double h,double g){//g�͍Ō��t�̒l
	
	double k1,k2,k3;
	
	while(g-h>t){//while��t��g����������Ƃ߂�悤�ɂ���
		
		k1=h*f(x,t);
		k2=h*f(x+k1/3.0,t+h/3.0);
		k3=h*f(x+2.0*k2/3.0,t+h*2.0/3.0);
		x+=(k1+3.0*k3)/4.0;
		t+=h;
				
	}
	return x;
}

int main(){
	
	ofstream f1("a.txt");
	ofstream f2("b.txt");
	ofstream f3("c.txt");
	ofstream f4("x.txt");
	double a=(double)0;
	double t=(double)0;
	double s=0.01;
	for(int i=0;i<10;i++){
		s=s*0.5;
		Heun(a,t,func1,s,1);
		cout << s <<",f1,"<< a << endl ;
		f1 << s << "  " << a << endl;
		a=0,t=0;
		Heun(a,t,func2,s,1);
		cout << s <<",f2,"<< a << endl ;
		f2 << s << "  " << a << endl;
		a=0,t=0;
		Heun(a,t,func3,s,1);
		cout << s <<",f3,"<< a << endl ;
		f3 << s << "  " << a << endl;
		a=1,t=0;
		Heun(a,t,func4,s,1);
		cout << s <<",f4,"<< a-exp(1) << endl ;
		f4 << s << "  " << a-exp(1) << endl;
		a=0,t=0;

	}
	
	return 0;


}