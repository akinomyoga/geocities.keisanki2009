inline void Heun3deg(double& x, double& t, double (*f)(double, double), double h){
#define k1     (h*f(x, t))
#define k2     (h*f(x+k1/3.0, t+h/3.0))
#define k3     (h*f(x+2.0*k2/3.0, t+2.0*h/3.0))
	x = x + (k1+3.0*k3)/4.0;
	t += h;
#undef k1
#undef k2
#undef k3
	return;
}