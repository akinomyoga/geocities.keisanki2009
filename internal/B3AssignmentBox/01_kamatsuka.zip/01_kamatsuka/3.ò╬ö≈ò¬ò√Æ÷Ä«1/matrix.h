#include <iostream>
#include <ctime>
#include <cstdlib>
#include <iomanip>

//�t�@�C���֌W�����B

//*********************** Matrix�N���X�̒�` ************************//
class Matrix{
private:
	int nrow;
	int ncol;
protected:
	double **element;
	
	void set_nrow(int row){nrow = row;}
	void set_ncol(int col){ncol = col;} 
	void alloc_element();
public:
	int get_nrow()const{return nrow;}
	int get_ncol()const{return ncol;}
	void Set_Rand();
	void Set_I();
	void Set_O();
	void Show()const;
	
	//double Det();						�����Ɏ�����������...determinant;
	
	Matrix();
	Matrix(int);
	Matrix(int,int);
	~Matrix();
	Matrix(const Matrix&);
		
	Matrix& operator+(const Matrix&);
	Matrix& operator*(const Matrix&);
	Matrix& operator=(const Matrix&);
	Matrix& operator-(const Matrix&);
	Matrix& operator-()const;				//-mat
	Matrix& operator~()const;				//transposed matrix
//	Matrix& operator^()const;				//inverse matrix
	double* operator[](int n)const;			//matrix.element[][] => matrix[][] 

};


//***************************  Matrix�N���X�̃����o�֐�  ***************************//
//constructor
Matrix::Matrix(){/*std::cout<<"ctor"<<std::endl;*/}
Matrix::Matrix(int n):nrow(n),ncol(n){
	//std::cout<<"ctr"<<std::endl;
	alloc_element();
}
Matrix::Matrix(int row,int col):nrow(row),ncol(col){
	alloc_element();
}
Matrix::~Matrix(){
//	std::cout<<"dtr"<<std::endl;
	for(int i=0;i<nrow;i++)
		delete element[i];
	delete element;
}

//�R�s�[�R���X�g���N�^
Matrix::Matrix(const Matrix& mat):nrow(mat.get_nrow()),ncol(mat.get_ncol()){
	alloc_element();
	for(int i=0;i<nrow;i++){
		for(int j=0;j<ncol;j++){
			element[i][j] = mat[i][j];
		}
	}
}
//�������̈�m��
void Matrix::alloc_element(){
	if(nrow&&ncol){
		element = new double*[nrow];
		for(int i=0;i<nrow;i++)	
			element[i] = new double[ncol];
		
		for(int i=0;i<nrow;i++){
			for(int j=0;j<ncol;j++){
				element[i][j] = 0.0;
			}
		}
	}
}
//���Z�q��`
Matrix& Matrix::operator=(const Matrix& x){
	if(this==&x) return *this;
	int row,col;
	row = this->get_nrow();
	col = this->get_ncol();

	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			(this->element)[i][j] = x.element[i][j];
		}
	}
	return *this;
}

Matrix& Matrix::operator+(const Matrix& mat){
	if(this->get_ncol()!=mat.get_ncol() || this->get_nrow()!=mat.get_nrow())
		return *this;
	int row,col;
	row=this->get_nrow();
	col=this->get_ncol();
		
	Matrix* temp = new Matrix(row,col);
	
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			temp->element[i][j] = this->element[i][j]+mat.element[i][j];
		}
	}
	return *temp;
}
Matrix& Matrix::operator-(const Matrix& x){
	if(this->get_ncol()!=x.get_ncol()||this->get_nrow()!=x.get_nrow())
		return *this;
	int row=this->get_nrow(),
		col=this->get_ncol();
		
	Matrix* temp = new Matrix(row,col);
		
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			temp->element[i][j] = this->element[i][j]-x.element[i][j];
		}
	}
	return *temp;
}

Matrix& Matrix::operator*(const Matrix& x){
	if(this->get_ncol()!=x.get_nrow())	return *this;	//�ς̒�`���ł��Ȃ�
		
	int row	= this->get_nrow(),
		col	= x.get_ncol(),
		rc  = this->get_ncol();
		
	Matrix *temp = new Matrix(row,col);
	
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			temp->element[i][j] = 0.0;
			for(int k=0;k<rc;k++){
				temp->element[i][j] += this->element[i][k]*x.element[k][j];
			}
		}
	}
	return *temp;
}
Matrix& Matrix::operator-()const{
	int row = this->get_nrow(),
		col = this->get_ncol();
		
	Matrix *temp = new Matrix(row,col);
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			temp->element[i][j] = -this->element[i][j];
		}
	}
	return *temp;
}
//�]�u�s��
Matrix& Matrix::operator~()const{
	int col=this->get_ncol(),
		row=this->get_nrow();
	
	Matrix *temp = new Matrix(col,row);
	for(int i=0;i<col;i++){
		for(int j=0;j<row;j++){
			temp->element[i][j] = this->element[j][i];
		}
	}
	return *temp;
}
//�z�񕗂Ɏg�p�ł���悤�ɁB
double* Matrix::operator[](int n)const{
	return this->element[n];
}


//*************************************	���̊֐���` ******************************************//

//�����_���ȍs������
void Matrix::Set_Rand(){
	static int n=1;
	int row,col;
	
	//1�x�ڂ̌Ăяo���̂ݎ��s
	if(n==1){
		srand((unsigned)time(NULL));
		n=0;
	}
	row = this->get_nrow();
	col = this->get_ncol();
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			this->element[i][j] = (double)rand()/RAND_MAX;
		}
	}
}
//�P�ʍs��ɂ���
void Matrix::Set_I(){
	int row=this->get_nrow(),
		col=this->get_ncol();
	if(row==col){
		for(int i=0;i<row;i++){
			this->element[i][i] = 1.0;
		}
	}
}

//�[���s��ɂ���B
void Matrix::Set_O(){
	int row=this->get_nrow(),
		col=this->get_ncol();
	
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			this->element[i][j] = 0.0;
		}
	}
}

//Matrix�̕\��
void Matrix::Show()const{
	int row,col;
	row = this->get_nrow();
	col = this->get_ncol();
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			std::cout<<std::setprecision(6)
				<<std::setw(8)
				<<this->element[i][j]<<"\t";
		}
		std::cout<<std::endl;
	}
	std::cout<<std::endl;
}
