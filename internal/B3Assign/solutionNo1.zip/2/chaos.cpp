#include <stdio.h>
#include "chaos.h"

#define R_INFTY			0.892486417967

double	r;
FILE	*fp;

double f(double s)
{
	return 4.0*r*s*(1.0-s);
}

int main()
{
	double	a;
	int		i;
	double	temp;

	fp=fopen("dat.txt","w");
	for(r=0.1;r<R_INFTY;r+=0.00001)
	{
		a	=0.5;
		for(i=0;i<4000;i++)
		{
			a=f(a);
			if(i == 1000)temp = a;
			if(i >  1000 && temp - 0.001 < a && a < temp + 0.001)break;
		}
		fprintf(fp,"%f %d\n",r,i-1000);
	}
	fclose(fp);
	return 0;
}