#include <stdio.h>
#include "chaos.h"

double	r;
FILE	*fp;

double f(double s)
{
	return 4.0*r*s*(1.0-s);
}

int main()
{
	double	a;
	int		i;
	fp=fopen("dat.txt","w");
	for(r=0.1;r<0.951;r+=0.001)
	{
		a	=0.5;
		for(i=0;i<1500;i++)
		{
			a=f(a);
			if(1000<i && i<1500)
			{
				fprintf(fp,"%f %f\n",r,a);
			}
		}
	}
	fclose(fp);
	return 0;
}