#include <stdio.h>
#include "chaos.h"

#define R_INFTY			0.892486417967

double	r;
FILE	*fp;

double f(double s)
{
	return 4.0*r*s*(1.0-s);
}

int main()
{
	double	a,b,c,d;
	int		i;
	r	= 0.91;

	fp=fopen("dat.txt","w");
	a	= 0.5;
	b	= 0.5001;
	for(i=1;i<10000;i++)
	{
		a=f(a);
		b=f(b);
		c=b/a;
		if(c>1.0)c=1.0/c;
		if(c<1.0-0.1)
		{
			fprintf(fp,"%d\n",i);
			break;
		}
	}
	fclose(fp);

	return 0;
}