#include <stdio.h>
#include "chaos.h"

#define R_INFTY			0.892486417967

double	r;
FILE	*fp;

double f(double s)
{
	return 4.0*r*s*(1.0-s);
}

int main()
{
	double	a,b,c,d;
	int		i;
	r	= 0.91;
	a	= 0.5;
	b	= 0.5001;
	c	= b-a;
	fp=fopen("dat.txt","w");
	for(i=1;i<=50;i++)
	{
		a=f(a);
		b=f(b);
		d=b-a;
		if(d<0.0)d=-d;
		d=d/c;
		fprintf(fp,"%d %f\n",i,d);
	}
	fclose(fp);

	return 0;
}