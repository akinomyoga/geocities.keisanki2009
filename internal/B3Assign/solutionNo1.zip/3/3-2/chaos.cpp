#include <stdio.h>
#include "chaos.h"

#define R_INFTY			0.892486417967

double	r;
FILE	*fp;

double f(double s)
{
	return 4.0*r*s*(1.0-s);
}

int main()
{
	double	a,b,c,d;
	int		i;
	r	= 0.91;

	fp=fopen("dat.txt","w");
	for(d=0.00001;d<=0.005;d+=0.00001)
	{
		a	= 0.5;
		b	= 0.5+d;
		for(i=1;i<10;i++)
		{
			a=f(a);
			b=f(b);
		}
		c=a/b;
		if(c>1)c=1.0/c;
		fprintf(fp,"%f %f\n",d,1.0-c);
	}
	fclose(fp);

	return 0;
}