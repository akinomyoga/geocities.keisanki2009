bool is_prime(int x){
	int i;
	if(x<2){
		return false;
	}
	for(i=2; i<=x/2; i++){
		if(!(x%i)){
			return false;
		}
	}
	return true;
}
