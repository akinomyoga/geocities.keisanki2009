#include <iostream>
using namespace std;

int main(){
	int i, j=0, s1=0, s2=0;
	for(i=0; i<=100; i++){
		s1 += i;
	}
	cout << "s1 = " << s1 << endl;
	while(j<=100){
		s2 += j;
		j++;
	}
	cout << "s2 = " << s2 << endl;
	return 0;
}