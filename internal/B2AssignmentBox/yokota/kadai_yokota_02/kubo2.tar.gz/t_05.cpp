#include <iostream>
using namespace std;

int main(){
	double x, y, z;
	y = 3.1415926535;
	z = 2.7182818284;
	x = (y + z)*y/(2*z)+y/2;
	if(x <= 10){
		cout << "xは10以下です" << endl;
	}
	else{
		cout << "xは10より大きいです" << endl;
	}
	cout << "終わり" << endl;
	return 0;
}