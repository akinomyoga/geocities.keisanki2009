bool can_create10(double a, double b);
bool can_create10(double a, double b, double c);
bool can_create10(int a, int b, int c, int d);

bool can_create10(double a, double b){
	if(a+b==10 || a+b==-10 || a-b == 10 || a-b == -10 || a*b == 10 || a*b == -10 || a/b == 10 || a/b == -10){
		return true;
	}
	return false;
}

bool can_create10(double a, double b, double c){
	if(can_create10(a+b, c) || can_create10(a-b, c) || can_create10(a*b, c) || can_create10(a/b, c) || can_create10(a, b+c) || can_create10(a, b-c) || can_create10(a, b*c) || can_create10(a, b/c)){
		return true;
	}
	return false;
}

bool can_create10(int a, int b, int c, int d){
	if(can_create10(a+b, c, d) || can_create10(a-b, c, d) || can_create10(a*b, c, d) || can_create10(a/b, c, d) || can_create10(a, b+c, d) || can_create10(a, b-c, d) || can_create10(a, b*c, d) || can_create10(a, b/c, d) || can_create10(a, b, c+d) || can_create10(a, b, c-d) || can_create10(a, b, c*d) || can_create10(a, b, c/d)){
		return true;
	}
	return false;
}
