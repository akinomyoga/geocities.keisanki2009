#include <iostream>
using namespace std;

__int64 nCr(int n, int r);

int main(){
	int i, j, k, n=1;
	cout << "n = ?" << endl;
	cin >> n;
	for(i=0; i<=n; i++){
		for(k=0; k<n-i; k++){
			cout << " ";
		}
		for(j=0; j<=i; j++){
			cout << (nCr(i, j)%2 ? "* " : "  ");
		}
		cout << endl;
	}
	return 0;
}

__int64 nCr(int n, int r){
	return 
		n<0 || r<0 || r>n ? 0 :
		n==0 || r==0 || r==n ? 1 : nCr(n-1, r-1) + nCr(n-1, r);
}
