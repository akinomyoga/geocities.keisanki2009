#include <iostream>
using namespace std;

int main(){
	int x = 0;
	cout << "xの値を入れてください" << endl;
	cin >> x;
	cout << "x = " << x << endl;
	return 0;
}
