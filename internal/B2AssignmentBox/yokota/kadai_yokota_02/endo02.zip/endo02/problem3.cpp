#include <iostream>
using namespace std;

int main(){
	double x;
	x = 0.111111111 + 0.9999999;
	cout<<"+"<<x<<endl;
    x = 0.1 - 0.01;
	cout<<"-"<<x<<endl;
	x = 0.1 * 0.1;
	cout<<"*"<<x<<endl;
	x = 0.1 / 0.1;
	cout<<"/"<<x<<endl;
	return 0;
}