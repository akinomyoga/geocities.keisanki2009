#include <iostream>
using namespace std;

int main(){
	double a, b, c, d;
	a = 0.33;
	b = 1.25;
	c = 3.16;
	d = (a + b + c) / 2;
	cout<<"���ϒl��"<<d<<endl;
	return 0;
}