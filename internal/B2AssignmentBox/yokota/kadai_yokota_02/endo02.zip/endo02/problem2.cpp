#include <iostream>
using namespace std;

int main(){
	int x,y;
	x = 721;
	y = 69;
	cout<<"x="<<x<<endl;
	cout<<"y="<<y;
	return 0;
}
