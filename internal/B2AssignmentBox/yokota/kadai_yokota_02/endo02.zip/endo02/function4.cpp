#include<iostream>
using namespace std;

int oddeven(int a){
	int b;
	b=a%2;
	if(b==0){
		return a;
	}
	else{
		return 0;
	}
}


int main(){
	int x;
	x = 0;
	for(int i=2;i<21;i++){
		
		x= x + oddeven(i);
	}
	cout<<x<<endl;
}