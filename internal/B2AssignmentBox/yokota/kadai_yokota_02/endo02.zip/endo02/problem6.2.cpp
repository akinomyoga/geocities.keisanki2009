#include<iostream>
using namespace std;

int main(){
    int s = 0;
	int i = 1;
	while(i <= 100){
		s = s + i;
	    i++;
	}
    cout<<"s="<<s;
	return 0;
}
