#include<iostream>
using namespace std;

int main(){
	int x=1;
	for(int i=2;i<101;i++){
		x = x + i;
	}
	cout<<x<<endl;
}