#include<iostream>
using namespace std;

double kakezan(double a, double b, double c){
	double z;
	z = a*b*c;
	return z;
}

int main(){
	double z;
	z = kakezan(1.2,3.2,5.0);
	cout<<z<<endl;
	return 0;
}