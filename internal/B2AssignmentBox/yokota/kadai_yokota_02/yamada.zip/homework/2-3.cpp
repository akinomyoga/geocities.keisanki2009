#include <iostream>
 using namespace std;

int f(){
		int i;
		int x=0;
		for(i=0;i<21;i=i+2){
			x=x+i;
		}
		return x;
}

int main(){
	int y;
		y=f();
	cout<<y<<endl;
	return 0;
}
