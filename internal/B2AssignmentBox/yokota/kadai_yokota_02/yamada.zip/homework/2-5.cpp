#include<iostream>
using namespace std;

int func(double x){
	int a;
	a=x+0.5;
	return a;
} 

int main(){
	double y;
	int b;
	cin>>y;
	b=func(y);
	cout<<b<<endl;
	return 0;
}
