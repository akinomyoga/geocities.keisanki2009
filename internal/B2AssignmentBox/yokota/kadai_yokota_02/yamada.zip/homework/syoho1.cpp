#include<iostream>
using namespace std;

main(){
	int x=0,i;
		for(i=0;i<101;i++){
			x=x+i;
		}
	cout<<x<<endl;
	return 0;
}

