#include<iostream>
using namespace std;

int func(int x){
	int z;
	z=x*2;
	return z;
}

int main(){
	int a;
	a=func(15);
	cout<<a<<endl;
	return 0;
}