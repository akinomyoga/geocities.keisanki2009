#include <iostream>
 using namespace std;

int main(){
	int x=0;
	cout<<"x=";
	cin>>x;
	cout<<"x="<<x;
	return 0;
}