#include <iostream>
 using namespace std;

int main(){
	int s=0;
	int t=0;
	int u=1;
		for(int i=1; i<=100; i++){
			s=s+i;
		}
	cout<<s<<endl;
	while(u<=100){
		t=t+u;
		u=u+1;
	}
	cout<<t<<endl;
	return 0;
}