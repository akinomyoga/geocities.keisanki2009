#include <iostream>
 using namespace std;

int main(){
	double x, y, z;
	y=1212.1212;
	z=12.12;
	x=(y+z)/z;
	if(x<100){
		cout<<"100�ȉ�"<<endl;
	}else{
		cout<<"100�ȏ�"<<endl;
	}
	return 0;
}