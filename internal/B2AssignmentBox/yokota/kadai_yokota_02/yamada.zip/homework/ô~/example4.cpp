#include <iostream>
 using namespace std;

int main(){
	double x, y, z;
	y=1212.1212;
	z=12.12;
	x=(y+z)/z;
	cout<<x;
	return 0;
}