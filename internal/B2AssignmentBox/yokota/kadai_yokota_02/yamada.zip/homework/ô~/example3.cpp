#include <iostream>
 using namespace std;

int main(){
	double x;
	x = 144 + 12;
	cout<<x<<endl;
	x = 144 - 12;
	cout<<x<<endl;
	x=144*12;
	cout<<x<<endl;
	x=144/12;
	cout<<x<<endl;
	return 0;
}