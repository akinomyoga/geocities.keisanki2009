#include <iostream>
 using namespace std;

int main(){
	cout<<"aaaaaa"<<endl;
	cout<<"bbbbb"<<endl;
	cout<<"cccc";
	cout<<"ddd";
	return 0;
}