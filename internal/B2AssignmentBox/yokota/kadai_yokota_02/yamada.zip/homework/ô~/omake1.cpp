#include<iostream>
#include<cstdlib>
#include<ctime>
 using namespace std;

 int main(){
	 srand((unsigned)time(NULL));

	 int mochikin = 100000;
	 int kakekin;
	 int i=0;

		 while(i==0){
			 cout<<"motikin ha "<<mochikin<<endl;

			 while(true){
				 cout<<"kakekin ha "<<endl;
				 cin>>kakekin;
				 if(kakekin > mochikin){
					 cout<<"tarinai"<<endl;
				 }else if (kakekin<0){
					 cout<<"muri"<<endl;
				 }else {
					 break;
				 }
			 }
			 int yosou;
			 cout<<"han 1 , chou 0"<<endl;
			 cin>>yosou;

			 int dice1,dice2;
			 dice1=rand()%6 +1;
			 dice2=rand()&6+1;
			 cout<<"sai ha "<<dice1<<","<<dice2<<endl;
			 if ((dice1+dice2)%2==yosou){
				 cout<<"atari"<<endl;
				 mochikin=mochikin+kakekin;
			 }else{
				 cout<<"hazure"<<endl;
				 mochikin=mochikin-kakekin;
			 }
			 cout<<"genzai"<<mochikin<<endl;

			 if(mochikin<=0){
				 cout<<"hasan"<<endl;
				 break;
			 }
			 cout<<"tuzukeru? yes 0, no 1"<<endl;
			 cin>>i;
			 if(i !=0){
				 cout<<"sayonara"<<endl;
			 }
			 cout<<endl;
		 }
		 return 0;
 }


