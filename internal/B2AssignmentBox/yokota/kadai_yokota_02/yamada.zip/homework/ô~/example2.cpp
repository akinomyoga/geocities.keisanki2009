#include <iostream>
 using namespace std;

int main(){
	int x, y;
	x = 323;
	y = 232323;
	cout<<"x="<<x<<endl;
	cout<<"y="<<y;
	return 0;
}