#include <iostream>
using namespace std;

int main(){
	int s=0;
	for(int i=0; i<=100; i++){
		s=s+i;
	}
	cout<<"s="<<s;
	return 0;
}