#include <iostream>
using namespace std;

int addition(int a){
	int x=0;
	int i;
	for(i=0;i<a+1;i++){
		x=x+i;
	}
	return x;
}
int main(){
	cout<<addition(100)<<endl;
}