#include <iostream>
using namespace std;

int main(){
	int i=0;
	int s=0;
	while(i>=0){
		s=s+i;
		i++;
		if(i==101){
			break;
		}
	}
	cout<<"s="<<s;
	return 0;
}