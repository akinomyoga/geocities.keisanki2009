#include <iostream>
using namespace std;

int addone(int x){
	int z;
	z=x*2;
	return z;
}
int main(){
	int a;
	a=addone(15);
	cout<<a<<endl;
	return 0;
}