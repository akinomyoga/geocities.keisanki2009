#include <iostream>
using namespace std;

int roundoff(double a){
	int b;
	double c;
	b=a;
	c=a-b;
	if(c>=0.5){
		return a+1;
	}
	if(c<0.5){
		return a;
	}
}
int main(){
	cout<<"3.14:"<<roundoff(3.14);
	return 0;
}

