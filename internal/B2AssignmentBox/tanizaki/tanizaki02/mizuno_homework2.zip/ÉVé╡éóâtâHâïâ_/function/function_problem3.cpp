#include <iostream>
using namespace std;

double multiplication(double x,double y,double z){
	double a=x*y*z;
	return a;
}
int main(){
	double b;
	b=multiplication(1.2 , 3.2 ,5.0);
	cout<<b<<endl;
	return 0;
}