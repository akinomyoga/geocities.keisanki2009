#include <iostream>
using namespace std;

int addevenfromtwo(int a){
	int i;
	int x=0;
	for(i=0;i<a+2;i=i+2){
		x=x+i;
	}
	return x;
}
int main(){
	cout<<addevenfromtwo(20)<<endl;
	return 0;
}
	