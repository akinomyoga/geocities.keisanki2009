//kansu2.cpp
#include<iostream>
using namespace std;

int addone(int x){
	int z;
	z = 2 * x;
	return z;
}

int main(){
	int a;
	a = addone(15);
	cout<<a<<endl;
	return 0;
}
