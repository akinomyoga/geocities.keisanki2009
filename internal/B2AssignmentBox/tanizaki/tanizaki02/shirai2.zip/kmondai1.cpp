//kmondai1.cpp
#include<iostream>
using namespace std;

int test(){
	int x;
	x = 2 * 3;
	return x;
}

int main(){
	int y;
	y = test();
	cout<<y<<endl;
	return 0;
}
