//renshumondai1.cpp
#include<iostream>
using namespace std;

int tashizan(){
	int x = 0;
	int i;
	for(i = 1;i < 101;i = i + 1){
		x = x + i;
	}
	return x;
}

int main()
{
	cout<<tashizan();
	return 0;
}

