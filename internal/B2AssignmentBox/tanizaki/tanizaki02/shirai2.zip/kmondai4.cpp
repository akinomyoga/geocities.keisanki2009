//kmondai4.cpp
#include<iostream>
using namespace std;

int addfromone(int a){
	int i;
	int x = 0;
	for(i = 0;i < a + 1;i = i + 2){
		x = x + i;
	}
	return x;
}

int main()
{
	cout<<addfromone(20);
	return 0;
}
