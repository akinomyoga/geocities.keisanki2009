//mondai6.1.cpp
#include<iostream>
using namespace std;

int main()
{
	int s = 0;
	int i = 1;
	while(i <=100){
		s = s + i;
		i = i + 1;
	}
	cout<<"s="<<s;
	return 0;
}
