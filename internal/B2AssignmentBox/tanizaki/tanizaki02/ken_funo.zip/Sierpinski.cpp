#include<iostream>

const int N=80;

int main(){
	__int64 x[N];
	__int64 y;
	x[0]=1;
	std::cout<<"*"<<std::endl;

	for(int i=1;i<N;i++){
		x[i]=1;
		for(int j=1;j<i;j++){
			x[i-j]=x[i-j-1]+x[i-j];
		}
		for(int a=0;a<=i;a++){
			y=x[a];
			y=y/2;
			y=y*2;
			if(y==x[a]){
			std::cout<<" ";
			}
			else{
				std::cout<<"*";
			}
		}
		std::cout<<"\n";
	}



	return 0;
}


