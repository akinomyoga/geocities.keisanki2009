#include<iostream>
using namespace std;

int main(){
	__int64 x[50][50];

	x[0][0]=1;
	
	for(int i=1;i<50;i++){
		x[i][0]=1;
		for(int k=1;k<=i;k++){
			if(k==i){
			x[i][k]=1;
			}
			else{
				x[i][k]=x[i-1][k-1]+x[i-1][k];

			}
		}
	}
	for(int j=0;j<50;j++){
	std::cout<<x[49][j] <<std::endl;
	}

	return 0;
}