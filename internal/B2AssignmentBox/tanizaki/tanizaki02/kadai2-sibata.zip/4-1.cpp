#include<iostream>
using namespace std;
int test(){
int x=2*3;
return x;
}
int main(){
int y=0;
y=test();
cout<<y<<endl;
return 0;
}