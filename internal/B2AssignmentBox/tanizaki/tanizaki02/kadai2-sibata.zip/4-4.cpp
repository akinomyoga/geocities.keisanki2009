#include<iostream>
using namespace std;
int add2(int n){
int i=0,j=0;
for(i=0;i<=n;i++){
if(i%2==0){
j+=i;
}
}
return j;
}
int main(){
int n=0;
n=add2(20);
cout<<n<<endl;
return 0;
}