#include<iostream>
using namespace std;
int sum(int n){
int i=0,j=0;
for(i=1;i<=n;i++){
j+=i;
}
return j;
}
int main(){
int n=0;
n=sum(100);
cout<<"1+2+...+100="<<n<<endl;
return 0;
}