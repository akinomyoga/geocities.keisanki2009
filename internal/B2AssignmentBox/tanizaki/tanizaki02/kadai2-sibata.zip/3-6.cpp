#include<iostream>
using namespace std;
int main(){
int i=0, j=0;
for(i=1;i<=100;i++){
j+=i;
}
cout<<"1+2+...+100="<<j<<endl;
return 0;
}