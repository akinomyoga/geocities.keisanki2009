#include<iostream>
using namespace std;
double product(double x, double y, double z){
double w=x*y*z;
return w;
}
int main(){
double x, y, z, w;
x=1.5;
y=3.2;
z=5.0;
w=product(x, y, z);
cout<<w<<endl;
return 0;
}