#include<iostream>
using namespace std;
int main(){
int i=1, j=0;
while(i<=100){
j+=i;
i++;
}
cout<<"1+2+...+100="<<j<<endl;
return 0;
}