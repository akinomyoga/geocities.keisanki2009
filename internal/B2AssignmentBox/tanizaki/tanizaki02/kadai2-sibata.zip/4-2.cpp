#include<iostream>
using namespace std;
int twice(int n){
n*=2;
return n;
}
int main(){
int n=0;
n=twice(15);
cout<<n<<endl;
return 0;
}