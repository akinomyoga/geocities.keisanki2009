#include <iostream>
using namespace std;

int main()
{
    int x = 0;
    int i;
    for(i = 1; i < 101; i++){
        x = x + i;
    }
    cout<<"x = "<<x<<endl;
    return 0;
}
