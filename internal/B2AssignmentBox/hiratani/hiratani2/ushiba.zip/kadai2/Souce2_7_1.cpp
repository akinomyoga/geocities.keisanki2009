#include <iostream>
using namespace std;

bool is_prime(int x)
{
    int y;
    int i = 2;
	y = x % 2;
	if(x == 2){
		y = 1;
	}else if(x > 2){
		for(i = 3; i < x; i += 2){
			y = x % i;
			if(y == 0){
				break;
			}
		}
	}else{
		y = 0;
	}
	if(y != 0){
		if(i == x){
			y = 1;
		}else{
			y = 0;
		}
	}else{
		y = 0;
	}
    return y;
}

int main()
{
    int x;
    cout<<"type natural number"<<endl;
    cin>>x;
	if(is_prime(x)){
		cout<<"x is prime number"<<endl;
	}else{
		cout<<"x is not prime number"<<endl;
	}
	return 0;
}
