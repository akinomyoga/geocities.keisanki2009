#include <iostream>
using namespace std;

int twice(int x)
{
    int y;
    y = x * 2;
    return y;
}

int main()
{
    int x = 15;
    int y;
    y = twice(x);
    cout<<"y = "<<y<<endl;
    return 0;
}
