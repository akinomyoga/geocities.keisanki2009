#include <iostream>
using namespace std;

int multiplication()
{
    int x;
    x = 2 * 3;
    return x;
}


int main()
{
    int y = multiplication();
    cout<<"y = "<<y<<endl;
    return 0;
}
