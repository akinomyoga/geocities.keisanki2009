#include <iostream>
using namespace std;

double multiply_three_numbers(double x, double y, double z)
{
    double w;
    w = x * y * z;
    return w;
}

int main()
{
    double x = 1.2;
    double y = 3.2;
    double z = 5.0;
    double w;
    w = multiply_three_numbers(x, y, z);
    cout<<"w = "<<w<<endl;
    return 0;
}
