#include <iostream>
using namespace std;

int add_even_numbers()
{
    int x = 0;
	int i;
    for(i = 1;i < 11;i++){
        x = x + 2*i;
    }
    return x;
}

int main()
{
    cout<<"x = "<<add_even_numbers()<<endl;
    return 0;
}

