#include <iostream>
using namespace std;

int round_off(double x)
{
    int y;
    if(x - (int)x < 0.5){
        y = (int)x;
    }else{
        y = (int)x + 1;
    }
    return y;
}

int main()
{
    double x;
    cout<<"type any number"<<endl;
    cin>>x;
    cout<<round_off(x);
    return 0;
}
