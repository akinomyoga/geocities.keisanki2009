#include <iostream>
using namespace std;
int addeven(int a){
	int s = 0;
	for(int i = 2; i <= a ; i += 2){
		s += i;
	}
	return s;
}
int main(){
	cout << addeven(20);
	return 0;
}