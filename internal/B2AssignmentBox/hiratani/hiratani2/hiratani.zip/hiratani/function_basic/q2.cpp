#include <iostream>
using namespace std;
int twice(int x){
	int y;
	y = x *2;
	return y;
}
int main(){
	int x;
	x =15;
	cout << twice(x);
	return 0;
}