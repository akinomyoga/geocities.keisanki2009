#include <iostream>
using namespace std;
int dtoi(double x){
	int xi = (int)x;
	double y = (x - (double)xi)*2;
	if(y >= 1){
		return xi +1;
	} else if(y <= -1){
		return xi -1;
	} else return xi;
}

int main(){
	double x;
	cout << "xの値を入力：" << endl;
	cin >> x;
	cout << dtoi(x);
	return 0;
}