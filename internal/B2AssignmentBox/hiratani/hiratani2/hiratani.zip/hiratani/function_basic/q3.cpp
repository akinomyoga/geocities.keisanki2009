#include <iostream>
using namespace std;
double multiply(double x,double y,double z){
	return x * y * z;
}
int main(){
	cout << multiply(1.2,3.2,5.0);
	return 0;
}