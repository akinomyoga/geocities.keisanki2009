#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int Dice(){
	srand( (unsigned int)time(NULL) );
	return rand() % 6 +1;
}
int main(){
	int money,bet,num;
	bool a;
	money = 100000;
	while(money != 0){
		cout << "掛け金?" << endl;
		cin >> bet;
		while(bet > money){
			cout << "お金が足りません" << endl;
			cin >> bet;
		}
		cout << "半->0,丁->1" << endl;
		cin >> a;
		num = Dice();
		if( (num % 2) == a ){
			money += bet;
		} else {
			money -= bet;
		}
		cout << "サイコロの目："<< num << "  所持金：" << money << endl;
		cout << "continue? yes->1, no->0" << endl;
		cin >> a;
		if(!a) break;
	}
}