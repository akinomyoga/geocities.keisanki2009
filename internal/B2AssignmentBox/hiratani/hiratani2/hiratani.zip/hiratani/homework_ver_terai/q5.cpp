#include <iostream>
using namespace std;
int main(){
	double x,y,z;
	y = 2.8;
	z = 4.96;
	x = (y * z) / z + y*y;
	if(x <= 10){
		cout << "xは10以下" << endl;
	} else {
		cout << "xは10より大きい" << endl;
	}
	return 0;
}
