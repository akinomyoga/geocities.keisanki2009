#include <iostream>
using namespace std;
int main(){
	int i,j,s1,s2;
	s1 = 0;
	for(i = 1; i <= 100 ; i++){
		s1 += i;
	}
	s2 = 0;
	j = 1;
	while (j <= 100){
		s2 += j;
		j++;
	}
	cout << "for:s=" << s1 << ", while:s=" << s2 <<endl;
}
