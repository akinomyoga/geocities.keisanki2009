#include <iostream>
using namespace std;
int main(){
	int x;
	cout << "xの値を入れてください" << endl;
	cin >> x;
	cout << "x=" << x << endl;
	return 0;
}