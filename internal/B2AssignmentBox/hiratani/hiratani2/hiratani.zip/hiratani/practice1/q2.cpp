#include <iostream>
using namespace std;
int sqrt(int x){ //平方根の概算
	int n = x / 2;
	int m = 0;
	int tmp = 0;
	for(int i =0 ; i<100 ;i++){
		//cout << n << m << tmp << endl;
		if(n*n > x){
			n = m + (n-m)/2;
		} else if(n*n < x){
			tmp = n;
			n = m + (n -m)*2;
			m = tmp;
		}
	}
	return n;
}
bool is_prime(int n){
	bool et[n+1];
	for(int i = 0; i <=n ; i++) et[i] = true; //prime->1 ,not prime->0
	for(int i =2; i <= sqrt(n) ; i++){
		if(et[i]){
			for(int j = 2; j <= n/i; j++){
				et[i*j] = false;
			}
		}
	}
	return et[n];
}
int main(){
	int a;
	cin >> a;
	cout << is_prime(a);
	return 0;
}