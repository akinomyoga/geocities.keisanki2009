#include <iostream>
using namespace std;

int main(){
  int x;
  x = 100+333;
  cout<<"+ "<<x<<endl;
    x = 100-333;
  cout<<"- "<<x<<endl;
    x = 100*333;
  cout<<"* "<<x<<endl;
    x = 100/333;
  cout<<"/ "<<x<<endl;
  return 0;
}
