#include <iostream>
using namespace std;

int main(){
  int x, y;
  x = 100; y = 333;
  cout<<"x="<<x<<endl;
  cout<<"y="<<y<<endl;
  return 0;
}
