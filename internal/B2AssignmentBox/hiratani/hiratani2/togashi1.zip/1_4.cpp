#include <iostream>
using namespace std;

int main(){
  double x, y, z, w;
  x = 100; y=333; z=24;
  w=x+y+z;
  cout<<"x+y+z="<<w<<endl;
  w=x+y*z;
  cout<<"x+y*z="<<w<<endl;
  w=x*y/z;
  cout<<"x*y*z="<<w<<endl;
  w=(x*x*x+y)/(x+y+z);
  cout<<"(x*x*x+y)/(x+y+z)="<<w<<endl;
  return 0;
}
