#include <iostream>
using namespace std;

int main(){
	int s = 0;
	for(int i = 1; i<=100; i++){
		s = s + i;
    }
	cout<<"s="<<s<<endl;
	return 0;
}