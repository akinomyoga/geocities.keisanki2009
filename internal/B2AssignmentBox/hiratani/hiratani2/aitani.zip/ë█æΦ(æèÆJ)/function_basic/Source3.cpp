#include<iostream>
using namespace std;

double test(double a,double b,double c){
	double x ;
	x = a*b*c ;
	return x;
}


int main(){
	double z;
	z = test(1.2, 3.2, 5.0);
	cout << z << endl;
	return 0;
}
