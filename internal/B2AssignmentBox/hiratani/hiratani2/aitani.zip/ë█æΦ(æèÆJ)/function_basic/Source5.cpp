#include<iostream>
using namespace std;

int test(double x){
	   int a;
	   a = x;
	   double b;
	   b = x - a;
	   if(b>=0.5){
		      return a+1;
	   }else{
		      return a;
	   }
}

int main(){
	    double x;
		cout<<"x�̒l����͂��Ă��������B"<<endl;
	    cin>>x;
		cout<< test(x)<<endl;
        return 0;
}