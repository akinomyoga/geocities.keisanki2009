#include<iostream>
using namespace std;

int test(){
	   int i;
	   int x = 0;
	   for(i=2; i<21; i=i+2){
		      x = x+i;
	   }
	   return x;
}


int main(){
	cout << test() << endl;
	return 0;
}
