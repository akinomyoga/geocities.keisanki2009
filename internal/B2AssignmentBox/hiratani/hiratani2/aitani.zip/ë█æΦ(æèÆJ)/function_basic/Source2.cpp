#include<iostream>
using namespace std;

int test(int x){
	    int z;
		z = 2 * x;
		return z;
}

int main(){
	    int y;
		y = test(15);
		cout<<y<<endl;
		return 0;
}
