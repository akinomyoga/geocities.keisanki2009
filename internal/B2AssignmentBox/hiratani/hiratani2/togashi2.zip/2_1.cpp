#include<iostream>
using namespace std;

int two_times_three(){
  int x;
  x=2*3;
  return x;
}
int main(){
  int a;
  a=two_times_three();
  cout<<a<<endl;
  return 0;
}
