#include<iostream>
using namespace std;

int sum(){
  int x=0;
  for(int i=2; i<=20; i+=2){
    x+=i;
  }
  return x;
}

int main(){
  int x=sum();
  cout<<x<<endl;
  return 0;
}
