#include<iostream>
using namespace std;

int x_times_three(int x){
  x*=2;
  return x;
}
int main(){
  int a;
  a=x_times_three(15);
  cout<<a<<endl;
  return 0;
}
