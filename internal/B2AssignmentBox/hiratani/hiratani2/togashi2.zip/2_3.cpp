#include<iostream>
using namespace std;

double multiply(double x, double y, double z){
  double w;
  w = x*y*z;
  return w;
}
int main(){
  double a;
  a=multiply(1.2, 3.2, 5.0);
  cout<<a<<endl;
  return 0;
}
